#pragma once

#ifndef __EMSCRIPTEN__
#include "vulkan_functions.h"
#include "VulkanTextureLoader.h"

struct VulkanMaterial
{
	vkTools::VulkanTexture Texture;
	VkDescriptorSet DescriptorSet;
};

void DestroyVkMaterial(VulkanMaterial& Material);
#else
// Stub for WASM/Emscripten to avoid Vulkan dependencies
struct VulkanMaterial
{
    void* Texture;
    void* DescriptorSet;
};

inline void DestroyVkMaterial(VulkanMaterial& Material) {}
#endif