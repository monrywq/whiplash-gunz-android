#include "stdafx.h"
#include "MFile.h"
#include "MZFileSystem.h"
#include "MXml.h"
#include "MZip.h"
#include "FileInfo.h"
#include "zip/zlib.h"
#include "MDebug.h"
#include "MUtil.h"
#include <algorithm>
#include <cassert>
#ifndef _WIN32
#include <unistd.h>
#endif
#include "Arena.h"

static void ReplaceBackSlashToSlash(char* szPath)
{
	int nLen = strlen(szPath);
	for(int i=0; i<nLen; i++){
		if(szPath[i]=='\\') szPath[i]='/';
	}
}

void GetRefineFilename(char *szRefine, int maxlen, const char *szSource)
{
    if (!szSource || !szSource[0]) {
        if (maxlen > 0) szRefine[0] = '\0';
        return;
    }

    // On WASM/VFS, files don't physically exist for realpath/GetRelativePath to work.
    // We normalize the path (slashes), resolve . and .. components, and strip legacy prefixes.
    // Stack-only implementation: no heap allocations.
	char szNormalized[512];
	strcpy_safe(szNormalized, sizeof(szNormalized), szSource);
	ReplaceBackSlashToSlash(szNormalized);

	const char* parts[128];
	int numParts = 0;

	char* context = nullptr;
	char* token = strtok_r(szNormalized, "/", &context);
	while (token) {
		if (token[0] == '.' && token[1] == '\0') {
			// skip "."
		} else if (token[0] == '.' && token[1] == '.' && token[2] == '\0') {
			if (numParts > 0) numParts--;
		} else {
			if (numParts < 128)
				parts[numParts++] = token;
		}
		token = strtok_r(nullptr, "/", &context);
	}

	char* out = szRefine;
	int remaining = maxlen - 1;
	for (int i = 0; i < numParts && remaining > 0; ++i) {
		if (i > 0 && remaining > 0) { *out++ = '/'; remaining--; }
		int len = (int)strlen(parts[i]);
		if (len > remaining) len = remaining;
		memcpy(out, parts[i], len);
		out += len;
		remaining -= len;
	}
	*out = '\0';
}

// Extract the filename portion after the last slash (no allocation, no reverse_iterator).
static StringView ExtractBasename(const StringView& path) {
	for (size_t i = path.size(); i > 0; --i) {
		char c = path.data()[i - 1];
		if (c == '/' || c == '\\')
			return path.substr(i);
	}
	return path;
}

// Asserts that the capacity of vec remains unchanged.
template <typename T>
static auto CapacityChecker(T& vec)
{
#ifdef _DEBUG
	struct CapacityChecker
	{
		CapacityChecker(T& vec) : vec{ vec } { Capacity = vec.capacity(); };
		~CapacityChecker() { assert(Capacity == vec.capacity()); }
		T& vec;
		size_t Capacity;
	};
	return CapacityChecker{ vec };
#else
	return 0;
#endif
}

void MZFileSystem::ClearFileList()
{
	Files.clear();
	Dirs.clear();
	NodeMap.clear();
	BasenameIndex.clear();
}

StringView MZFileSystem::AllocateString(const StringView& Src)
{
	const auto size = Src.size() + 1;
	Strings.emplace_back(std::make_unique<char[]>(size));

	auto ptr = Strings.back().get();
	strcpy_safe(ptr, size, Src);
	
	return{ ptr, Src.size() };
}

static bool IsArchivePath(const StringView& Path)
{
	const auto ExtIndex = Path.find_last_of('.');
	if (ExtIndex == Path.npos)
		return false;

	const auto ExtLen = Path.size() - ExtIndex;
	if (ExtLen < 4)
		return false;

	const auto Ext = Path.data() + ExtIndex;
	return Ext && (_stricmp(Ext, "." DEF_EXT) == 0 || _stricmp(Ext, ".zip") == 0);
}

template <typename T>
using AllocType = ArenaAllocator<T>;

struct PreprocessedDir
{
	explicit PreprocessedDir(const AllocType<char>& Alloc) : Subdirs{ Alloc }, Files{ Alloc } {}

	// Path to the directory.
	// If the directory is an archive, this is formatted as a directory (i.e. no archive extension).
	StringView Path;

	// If this directory is an archive, this is the path to the archive file.
	// Otherwise, it's empty.
	StringView ArchivePath;

	std::vector<PreprocessedDir, AllocType<PreprocessedDir>> Subdirs;
	std::vector<MZFileDesc, AllocType<MZFileDesc>> Files;
};

struct PreprocessedFileTree
{
	explicit PreprocessedFileTree(const AllocType<char>& Alloc) : Alloc{ Alloc }, Root { Alloc } {}

	AllocType<char> Alloc;
	int NumFiles{};
	int NumDirectories{};
	int NumArchives{};
	PreprocessedDir Root;
};

void MZFileSystem::AddFilesInArchive(PreprocessedFileTree& Tree, PreprocessedDir& ArchiveDir, MZip& Zip)
{
	const auto Count = int(Zip.GetFileCount());

	Tree.NumFiles += Count;

	for (int i = 0; i < Count; i++)
	{
		const auto Filename = Zip.GetFileName(i);

		{
			const auto lastchar = Filename.back();
			if (lastchar == '\\' || lastchar == '/') {
				continue;
			}
		}

		ArchiveDir.Files.emplace_back();
		auto&& Child = ArchiveDir.Files.back();

		char Path[MFile::MaxPath];
		sprintf_safe(Path, "%.*s%.*s",
			ArchiveDir.Path.size(), ArchiveDir.Path.size() ? ArchiveDir.Path.data() : "",
			Filename.size(), Filename.data());
		Child.Path = AllocateString(Path);
		Child.ArchivePath = ArchiveDir.ArchivePath;

		Child.Size = Zip.GetFileLength(i);
		Child.ArchiveOffset = Zip.GetFileArchiveOffset(i);
		Child.CompressedSize = Zip.IsFileCompressed(i) ? Zip.GetFileCompressedSize(i) : 0;
	}
}

void MZFileSystem::MakeDirectoryTree(PreprocessedFileTree& Tree,
	const StringView& FullPath, PreprocessedDir& Dir)
{
	char szFilter[MFile::MaxPath];
	sprintf_safe(szFilter, "%.*s*",
		FullPath.size(), FullPath.size() ? FullPath.data() : "");

	for (auto&& FileData : MFile::Glob(szFilter))
	{
		if (strcmp(FileData.Name, ".") == 0 || strcmp(FileData.Name, "..") == 0)
			continue;

		auto AddSubdir = [&](const StringView& Filename) -> auto&
		{
			char Path[MFile::MaxPath];
			sprintf_safe(Path, "%.*s%.*s/",
				Dir.Path.size(), Dir.Path.size() ? Dir.Path.data() : "",
				Filename.size(), Filename.data());

			Dir.Subdirs.emplace_back(Tree.Alloc);
			auto&& Subdir = Dir.Subdirs.back();

			Subdir.Path = AllocateString(Path);

			return Subdir;
		};

		const auto IsDirectory = (FileData.Attributes & MFile::Attributes::Subdir) != 0;

		if (IsDirectory)
		{
			auto&& Subdir = AddSubdir(FileData.Name);

			char SubdirFullPath[MFile::MaxPath];
			sprintf_safe(SubdirFullPath, "%.*s%s/",
				FullPath.size(), FullPath.size() ? FullPath.data() : "",
				FileData.Name);

			MakeDirectoryTree(Tree, SubdirFullPath, Subdir);

			++Tree.NumDirectories;
		}
		else if (IsArchivePath(FileData.Name))
		{
			StringView Filename{ FileData.Name };
			Filename = Filename.substr(0, Filename.find_last_of('.'));
			auto&& Subdir = AddSubdir(Filename);

			char ArchivePath[MFile::MaxPath];
			sprintf_safe(ArchivePath, "%.*s%s",
				Dir.Path.size(), Dir.Path.size() ? Dir.Path.data() : "",
				FileData.Name);

			Subdir.ArchivePath = AllocateString(ArchivePath);

			char FullArchivePath[MFile::MaxPath];
			sprintf_safe(FullArchivePath, "%s%.*s",
				BasePath.c_str(),
				Subdir.ArchivePath.size(), Subdir.ArchivePath.size() ? Subdir.ArchivePath.data() : "");

			auto fp = fopen(FullArchivePath, "rb");
			if (!fp)
			{
				MLog("fopen on %s failed\n", FullArchivePath);
				assert(false);
				continue;
			}

			MZip Zip;
			Zip.Initialize(fp, MZFile::GetReadMode());

			AddFilesInArchive(Tree, Subdir, Zip);

			++Tree.NumArchives;
		}
		else
		{
			Dir.Files.emplace_back();
			auto&& File = Dir.Files.back();

			char Path[MFile::MaxPath];
			sprintf_safe(Path, "%.*s%s",
				Dir.Path.size(), Dir.Path.size() ? Dir.Path.data() : "",
				FileData.Name);

			File.Path = AllocateString(Path);
			File.ArchiveOffset = 0;
			File.CompressedSize = 0;
			assert(FileData.Size <= SIZE_MAX);
			File.Size = static_cast<size_t>(FileData.Size);

			++Tree.NumFiles;
		}
	}
}

void MZFileSystem::UpdateFileList(PreprocessedDir& Src, MZDirDesc& Dest)
{
	if (Src.Subdirs.empty() && Src.Files.empty())
		return;

	auto&& chk1 = CapacityChecker(Files);
	auto&& chk2 = CapacityChecker(Dirs);

	Dest.Path = Src.Path;

	auto AddNode = [&](auto& x, bool IsDirectory) {
		auto [it, inserted] = NodeMap.emplace(x.Path, MZNode{ &x, IsDirectory });
		if (!IsDirectory && inserted) {
			StringView basename = ExtractBasename(x.Path);
			if (!basename.empty())
				BasenameIndex.emplace(basename, &it->second);
		}
	};

	if (Src.Files.empty())
	{
		Dest.Files = nullptr;
		Dest.NumFiles = 0;
	}
	else
	{
		size_t FilesIndex = Files.size();
		Files.insert(std::end(Files), std::begin(Src.Files), std::end(Src.Files));
		Dest.Files = &Files[FilesIndex];
		Dest.NumFiles = Src.Files.size();

		for (auto&& File : Dest.FilesRange())
			AddNode(File, false);
	}

	if (Src.Subdirs.empty())
	{
		Dest.Subdirs = nullptr;
		Dest.NumSubdirs = 0;
	}
	else
	{
		size_t SubdirsIndex = Dirs.size();
		Dest.NumSubdirs = Src.Subdirs.size();
		Dirs.resize(Dirs.size() + Dest.NumSubdirs);
		Dest.Subdirs = &Dirs[SubdirsIndex];

		for (size_t i = 0; i < Dest.NumSubdirs; ++i)
		{
			auto&& SrcSubdir = Src.Subdirs[i];
			auto&& DestSubdir = Dirs[SubdirsIndex + i];
			DestSubdir.Parent = &Dest;
			UpdateFileList(SrcSubdir, DestSubdir);
		}

		for (auto&& Subdir : Dest.SubdirsRange())
			AddNode(Subdir, true);
	}
}

unsigned MGetCRC32(const char *data, int nLength)
{
	uLong crc = crc32(0, Z_NULL, 0);
	crc = crc32(crc, reinterpret_cast<const Byte*>(data), nLength);
	return crc;
}

MZFileSystem::MZFileSystem() = default;
MZFileSystem::~MZFileSystem() = default;

bool MZFileSystem::Create(std::string BasePathArgument)
{
	// Normalize the BasePath using the same logic as GetNode to ensure consistency
	char szRefinedBase[MFile::MaxPath];
	GetRefineFilename(szRefinedBase, sizeof(szRefinedBase), BasePathArgument.c_str());
	BasePath = szRefinedBase;

	// Add slash to end of path if missing, but only if path is not empty
	if (!BasePath.empty() && BasePath.back() != '/' && BasePath.back() != '\\')
		BasePath += '/';

	u8 ArenaBuffer[1024 * 16];
	Arena arena{ ArenaBuffer, std::size(ArenaBuffer) };

	PreprocessedFileTree Tree{ ArenaAllocator<char>{ &arena } };
	Tree.NumDirectories++; // Root.
	MakeDirectoryTree(Tree, BasePath, Tree.Root);

	DMLog("Number of files: %d\n"
		"Number of archives: %d\n"
		"Number of directories: %d\n",
		Tree.NumFiles, Tree.NumArchives, Tree.NumDirectories);

	const auto NumNodes = Tree.NumArchives + Tree.NumDirectories + Tree.NumFiles;
	const auto NumDirs = Tree.NumArchives + Tree.NumDirectories;
	NodeMap.reserve(NumNodes);
	BasenameIndex.reserve(Tree.NumFiles);
	Files.reserve(Tree.NumFiles);
	Dirs.reserve(NumDirs);

	Strings.shrink_to_fit();

	Dirs.emplace_back();
	auto&& Root = Dirs.back();
	UpdateFileList(Tree.Root, Root);

	return true;
}

int MZFileSystem::GetFileCount() const
{
	return static_cast<int>(Files.size() + RuntimeFiles.size());
}

const StringView& MZFileSystem::GetFileName(int i) const
{
    static StringView EmptyStringView{};
	assert(i >= 0 && i < int(GetFileCount()));
	auto* desc = GetFileDesc(i);
    return desc ? desc->Path : EmptyStringView;
}

const MZFileDesc* MZFileSystem::GetFileDesc(int i) const
{
	if (i < 0) return nullptr;
    
    if (i < static_cast<int>(Files.size()))
    {
	    return &Files[i];
    }
    
    int rtIndex = i - static_cast<int>(Files.size());
    if (rtIndex < static_cast<int>(RuntimeFiles.size()))
    {
        return RuntimeFiles[rtIndex].get();
    }
    
    return nullptr;
}

const MZFileDesc* MZFileSystem::GetFileDesc(const StringView& Path) const
{
	auto Node = GetNode(Path);
	if (!Node || !Node->IsFile())
		return nullptr;

	return &Node->AsFile();
}

const MZDirDesc* MZFileSystem::GetDirectory(const StringView& Path) const
{
	auto Node = GetNode(Path);
	if (!Node || !Node->IsDirectory())
		return nullptr;

	return &Node->AsDirectory();
}

const MZNode* MZFileSystem::GetNode(const StringView& Path) const
{
    // 1. Precise Match
    char szRefined[MFile::MaxPath];
    GetRefineFilename(szRefined, sizeof(szRefined), Path.data());
    
	auto it = NodeMap.find(szRefined);
	if (it != NodeMap.end())
		return &it->second;

    // 1.5 Directory Fallback
    // Directories in NodeMap always end with '/' but GetRefineFilename strips it.
    // So we try appending it back.
    char szDirFallback[MFile::MaxPath];
    sprintf_safe(szDirFallback, "%s/", szRefined);
    it = NodeMap.find(szDirFallback);
    if (it != NodeMap.end())
        return &it->second;

	// 2. Basename-indexed fallback (O(k) where k = files with same basename)
    // Legacy assets may be requested with inconsistent directory prefixes
    // (e.g. ELU materials use mesh dir instead of actual texture dir).
    // We match by basename via the pre-built index, then score candidates
    // by leading path component similarity.

    StringView RefinedPath{szRefined};
    StringView RequestedBasename = ExtractBasename(RefinedPath);
    if (RequestedBasename.empty())
        return nullptr;

    auto range = BasenameIndex.equal_range(RequestedBasename);
    if (range.first == range.second)
        return nullptr;

    const MZNode* bestMatch = nullptr;
    StringView bestMatchPath;
    int bestScore = -1;

    for (auto rangeIt = range.first; rangeIt != range.second; ++rangeIt)
    {
        const MZNode* node = rangeIt->second;
        if (node->IsDirectory()) continue;

        StringView NodePath = node->AsFile().Path;

        // Score: count how many leading path components match (case-insensitive)
        int score = 0;
        const char* rp = RefinedPath.data();
        const char* np = NodePath.data();
        size_t rLen = RefinedPath.size(), nLen = NodePath.size();
        size_t ri = 0, ni = 0;
        while (ri < rLen && ni < nLen) {
            size_t rEnd = ri;
            while (rEnd < rLen && rp[rEnd] != '/' && rp[rEnd] != '\\') rEnd++;
            size_t nEnd = ni;
            while (nEnd < nLen && np[nEnd] != '/' && np[nEnd] != '\\') nEnd++;

            StringView rComp{rp + ri, rEnd - ri};
            StringView nComp{np + ni, nEnd - ni};
            if (PathComparer{}(rComp, nComp))
                score++;
            else
                break;

            ri = (rEnd < rLen) ? rEnd + 1 : rEnd;
            ni = (nEnd < nLen) ? nEnd + 1 : nEnd;
        }

        if (score > bestScore) {
            bestScore = score;
            bestMatch = node;
            bestMatchPath = NodePath;
        }
    }

    if (bestMatch) {
        MLog("MZFileSystem: Fallback for '%.*s' -> '%.*s' (score=%d)\n",
            (int)Path.size(), Path.data(),
            (int)bestMatchPath.size(), bestMatchPath.data(), bestScore);
        return bestMatch;
    }

	return nullptr;
}

int MZFileSystem::GetFileLength(int i)
{
	auto pDesc = GetFileDesc(i);
	if (!pDesc)
		return 0;

	return pDesc->Size;
}

int MZFileSystem::GetFileLength(const StringView& szFileName)
{
	auto pDesc = GetFileDesc(szFileName);
	if (!pDesc)
		return 0;

	return pDesc->Size;
}

#ifdef WIN32
class MMappedFile
{
public:
	MMappedFile() {}
	MMappedFile(const char* Filename);
	MMappedFile(const MMappedFile&) = delete;
	MMappedFile(MMappedFile&&);
	~MMappedFile();
	MMappedFile& operator =(MMappedFile&& src)
	{
		this->~MMappedFile();
		new (this) MMappedFile(std::move(src));
		return *this;
	}

	bool Dead() const { return bDead; }
	auto GetPointer() const { return reinterpret_cast<const char*>(View); }
	auto GetSize() const { return Size; }

private:
	bool bDead = true;
	HANDLE File = INVALID_HANDLE_VALUE;
	HANDLE Mapping = INVALID_HANDLE_VALUE;
	HANDLE View = INVALID_HANDLE_VALUE;
	size_t Size = 0;
};
#endif

#ifdef WIN32
#define ARCHIVE_CACHE_MMAP
#endif

void MZFileSystem::CacheArchive(const StringView& Filename)
{
	char FilenameWithExtension[MFile::MaxPath];
	sprintf_safe(FilenameWithExtension, "%.*s.%s", (int)Filename.size(), Filename.data(), DEF_EXT);
	CacheArchiveFrom(Filename, FilenameWithExtension);
}

void MZFileSystem::CacheArchiveFrom(const StringView& Prefix, const char* ArchiveFilePath)
{
    // Load the entire file into memory first
    // This avoids fopen/fseek issues and ensures consistent access
    FILE* fp = fopen(ArchiveFilePath, "rb");
    if (!fp) {
        MLog("MZFileSystem::CacheArchiveFrom -- fopen failed on %s\n", ArchiveFilePath);
        return;
    }

    fseek(fp, 0, SEEK_END);
    long fileSize = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    MLog("CacheArchiveFrom: Loading %s (Size: %ld bytes, prefix: %.*s) into memory\n",
        ArchiveFilePath, fileSize, (int)Prefix.size(), Prefix.data());

    // Check for obvious truncation
    if (fileSize < 22) { // Min zip size
         MLog("ERROR: File too small to be an archive!\n");
         fclose(fp);
         return;
    }

    auto archiveBuffer = std::make_unique<char[]>(fileSize);
    if (fread(archiveBuffer.get(), 1, fileSize, fp) != static_cast<size_t>(fileSize)) {
        MLog("ERROR: Failed to read full archive into memory!\n");
        fclose(fp);
        return;
    }
    fclose(fp);

	MZip Zip;
	if (!Zip.Initialize(archiveBuffer.get(), fileSize, MZFile::GetReadMode()))
	{
		MLog("MZFileSystem::CacheArchiveFrom -- MZip::Initialize (Memory) failed!\n");
		return;
	}

	auto FileCount = Zip.GetFileCount();

	// Consolidated loop: Register files and cache data
	for (int i = 0; i < FileCount; i++)
	{
		char Name[256];
		Zip.GetFileName(i, Name);

		char AbsName[256];
		sprintf_safe(AbsName, "%.*s/%s", (int)Prefix.size(), Prefix.data(), Name);

		// Direct NodeMap lookup — DO NOT use GetFileDesc/GetNode here!
		// GetNode has a greedy filename fallback that matches any file with
		// the same basename (e.g. "model/npc.xml" → "system/npc.xml"),
		// which prevents correct registration of new files from deferred archives.
		const MZFileDesc* Desc = nullptr;
		{
			char szRefined[MFile::MaxPath];
			GetRefineFilename(szRefined, sizeof(szRefined), AbsName);
			auto nodeIt = NodeMap.find(szRefined);
			if (nodeIt != NodeMap.end() && nodeIt->second.IsFile())
				Desc = &nodeIt->second.AsFile();
		}
		if (!Desc)
		{
            // Register as RuntimeFile
			auto NewDesc = std::make_unique<MZFileDesc>();
			NewDesc->Path = AllocateString(AbsName);
			NewDesc->ArchivePath = AllocateString(ArchiveFilePath);
			NewDesc->ArchiveOffset = Zip.GetFileArchiveOffset(i);
			NewDesc->CompressedSize = 0;
			NewDesc->Size = Zip.GetFileLength(i);

			RuntimeFiles.push_back(std::move(NewDesc));
			Desc = RuntimeFiles.back().get();
			auto [nodeIt2, inserted2] = NodeMap.emplace(Desc->Path, MZNode(Desc, false));
			if (inserted2) {
				StringView basename = ExtractBasename(Desc->Path);
				if (!basename.empty())
					BasenameIndex.emplace(basename, &nodeIt2->second);
			}
		}

		if (Desc)
		{
            if (CachedFileMap.find(Desc) != CachedFileMap.end()) {
                continue;
            }

    		auto Size = Zip.GetFileLength(i);
    		auto p = std::make_unique<char[]>(Size);
    		// ReadFile now uses the memory buffer version
    		if (!Zip.ReadFile(i, p.get(), Size)) {
    			MLog("MZFileSystem::CacheArchiveFrom - MZip::ReadFile on %s failed!\n", Name);
    			continue;
    		}

            CachedFileMap.emplace(Desc, std::move(p));
		}
	}

	DMLog("Cached %d files for archive %.*s\n", FileCount, (int)Prefix.size(), Prefix.data());
}

void MZFileSystem::ReleaseCachedArchives()
{
	CachedFileMap.clear();
}

#ifdef WIN32
MMappedFile::MMappedFile(const char * Filename)
{
	File = CreateFileA(Filename, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (File == INVALID_HANDLE_VALUE)
	{
		MLog("MMappedFile::MMappedFile - CreateFile failed on %s! GetLastError() = %d\n",
			Filename, GetLastError());
		return;
	}

	Size = GetFileSize(File, nullptr);

	char FileMappingName[256];
	sprintf_safe(FileMappingName, "GunzCache_%s", Filename);
	Mapping = CreateFileMapping(File, 0, PAGE_READONLY, 0, 0, FileMappingName);
	if (Mapping == NULL)
	{
		assert(false);
		return;
	}

	View = MapViewOfFile(Mapping, FILE_MAP_READ, 0, 0, 0);
	if (View == NULL)
	{
		assert(false);
		return;
	}

	bDead = false;
}

MMappedFile::~MMappedFile()
{
	if (View != INVALID_HANDLE_VALUE) {
		auto Success = UnmapViewOfFile(View);
		assert(Success);
	}
	if (Mapping != INVALID_HANDLE_VALUE) {
		auto Success = CloseHandle(Mapping);
		assert(Success);
	}
	if (File != INVALID_HANDLE_VALUE) {
		auto Success = CloseHandle(File);
		assert(Success);
	}
}

MMappedFile::MMappedFile(MMappedFile && src)
	: bDead(src.bDead), View(src.View), Mapping(src.Mapping), File(src.File)
{
	src.bDead = true;
	src.View = INVALID_HANDLE_VALUE;
	src.Mapping = INVALID_HANDLE_VALUE;
	src.File = INVALID_HANDLE_VALUE;
}
#endif

static const MZDirDesc* Down(const MZDirDesc* Dir);

static const MZDirDesc* DownThroughRange(Range<const MZDirDesc*> range)
{
	for (auto& Subdir : range)
		if (auto NextDir = Down(&Subdir))
			return NextDir;

	return nullptr;
}

static const MZDirDesc* DownThroughSubdirs(const MZDirDesc* Dir)
{
	return DownThroughRange(Dir->SubdirsRange());
}

static const MZDirDesc* Down(const MZDirDesc* Dir)
{
	if (Dir->NumFiles)
		return Dir;

	return DownThroughSubdirs(Dir);
}

static const MZDirDesc* AcrossOrUp(const MZDirDesc* Dir, const MZDirDesc* Root)
{
	while (true)
	{
		if (Dir == Root)
			return Dir;
		auto End = Dir->Parent->Subdirs + Dir->Parent->NumSubdirs;
		if (auto NextDir = DownThroughRange(MakeRange(Dir + 1, End)))
			return NextDir;
		Dir = Dir->Parent;
	}
}

void RecursiveMZFileIterator::AdvanceToNextFile()
{
	if (FileIndex < int(CurrentSubdir->NumFiles) - 1)
	{
		++FileIndex;
		return;
	}

	if (auto NextDir = DownThroughSubdirs(CurrentSubdir))
	{
		CurrentSubdir = NextDir;
		FileIndex = 0;
		return;
	}

	CurrentSubdir = AcrossOrUp(CurrentSubdir, &Dir);
	if (CurrentSubdir == &Dir)
	{
		FileIndex = Dir.NumFiles;
	}
	else
	{
		FileIndex = 0;
	}
}

Range<RecursiveMZFileIterator> FilesInDirRecursive(const MZDirDesc& Dir)
{
	auto CurrentSubdir = Down(&Dir);

	return{
		RecursiveMZFileIterator{ Dir, CurrentSubdir, 0 },
		RecursiveMZFileIterator{ Dir, &Dir, int(Dir.NumFiles) },
	};
}