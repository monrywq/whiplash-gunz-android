#pragma once
#include "MAsyncDBJob.h"
#include <string>

class MAsyncDBJob_GoogleOAuth : public MAsyncJob
{
public:
    MAsyncDBJob_GoogleOAuth() : MAsyncJob(MASYNCJOB_GOOGLE_OAUTH) {}
    virtual ~MAsyncDBJob_GoogleOAuth() {}

    void Input(const MUID& CommUID, std::string IdToken,
               int CommandVersion, u32 ChecksumPack,
               u32 Major, u32 Minor, u32 Patch, u32 Revision,
               bool bFreeLoginIP, const std::string& strCountryCode3);

    // Output fields filled by Run()
    bool         Verified         = false;
    unsigned int AID              = 0;
    std::string  SessionToken;
    int64_t      SessionExpiresAt = 0;
    std::string  ErrorMsg;

    const MUID&         GetCommUID()        const { return m_CommUID; }
    u32                 GetChecksumPack()   const { return m_ChecksumPack; }
    int                 GetCommandVersion() const { return m_CommandVersion; }
    bool                IsFreeLoginIP()     const { return m_bFreeLoginIP; }
    const std::string&  GetCountryCode3()   const { return m_strCountryCode3; }

    virtual void Run(void* pContext) override;

private:
    MUID        m_CommUID;
    std::string m_IdToken;
    int         m_CommandVersion  = 0;
    u32         m_ChecksumPack    = 0;
    u32         m_Major = 0, m_Minor = 0, m_Patch = 0, m_Revision = 0;
    bool        m_bFreeLoginIP    = false;
    std::string m_strCountryCode3;
};
