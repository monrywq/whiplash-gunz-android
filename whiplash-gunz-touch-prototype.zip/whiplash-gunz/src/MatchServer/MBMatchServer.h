#ifndef MBMATCHSERVER_H
#define MBMATCHSERVER_H

#include "MMatchServer.h"
#include "MBMatchServerConfigReloader.h"
#include <memory>
#include "MLocator.h"
#include "MFile.h"
#ifdef USE_WEBSOCKET
#include "WebSocketListener.h"
#endif

class COutputView;
class CCommandLogView;

class MBMatchServer : public MMatchServer
{
private :
	MBMatchServerConfigReloader m_ConfigReloader;

public:
#ifdef MFC
	COutputView*		m_pView;
	CCommandLogView*	m_pCmdLogView;
#endif

	MUID m_uidKeeper;
protected:
	virtual bool OnCreate();
	virtual void OnDestroy();
	virtual void OnPrepareCommand(MCommand* pCommand);
	virtual bool OnCommand(MCommand* pCommand);

	virtual void OnRun() override;
	virtual bool OnAdminReloadConfig(const std::vector<std::string>& fileNames,
		std::string& outError) override;

#ifdef USE_WEBSOCKET
	// Overrides MServer::NetSend to route WebSocket handles to WsListener.
	virtual bool NetSend(uintptr_t handle, void* data, int size) override;
	// Overrides MServer::NetDisconnect to also close WebSocket connections and
	// clear their context before MC_NET_CLEAR can free the MCommObject.
	virtual void NetDisconnect(uintptr_t handle) override;
#endif

public:
	MBMatchServer(COutputView* pView=NULL);
	virtual void Shutdown();
	virtual void Log(unsigned int nLogLevel, const char* szLog);
	void OnViewServerStatus();

private :
	bool InitSubTaskSchedule();
	bool AddClanServerAnnounceSchedule();
	bool AddClanServerSwitchDownSchedule();
	bool AddClanServerSwitchUpSchedule();
	
	void OnScheduleAnnounce( const char* pszAnnounce );
	void OnScheduleClanServerSwitchDown();
	void OnScheduleClanServerSwitchUp();

	const MUID GetKeeperUID() const { return m_uidKeeper; }
	void SetKeeperUID( const MUID& uidKeeper ) { m_uidKeeper = uidKeeper; }

	void WriteServerInfoLog();

protected :
	bool IsKeeper( const MUID& uidKeeper );

	void OnResponseServerStatus( const MUID& uidSender );
	void OnRequestServerHearbeat( const MUID& uidSender );
	void OnResponseServerHeartbeat( const MUID& uidSender );
	void OnRequestConnectMatchServer( const MUID& uidSender );
	void OnResponseConnectMatchServer( const MUID& uidSender );
	void OnRequestKeeperAnnounce( const MUID& uidSender, const char* pszAnnounce );
	void OnRequestStopServerWithAnnounce( const MUID& uidSender );
	void OnResponseStopServerWithAnnounce( const MUID& uidSender );
	void OnRequestSchedule( const MUID& uidSender, 
							const int nType, 
							const int nYear, 
							const int nMonth, 
							const int nDay, 
							const int nHour, 
							const int nMin,
							const int nCount,
							const int nCommand,
							const char* pszAnnounce );
	void OnResponseSchedule( const MUID& uidSender, 
							 const int nType, 
							 const int nYear, 
							 const int nMonth, 
							 const int nDay, 
							 const int nHour, 
							 const int nMin,
							 const int nCount,
							 const int nCommand,
							 const char* pszAnnounce );
	void OnRequestKeeperStopServerSchedule( const MUID& uidSender, const char* pszAnnounce );
	void OnResponseKeeperStopServerSchedule( const MUID& uidSender, const char* pszAnnounce );
	void OnRequestDisconnectServerFromKeeper( const MUID& uidSender );
	void OnRequestReloadServerConfig( const MUID& uidSender, const string& strFileList );
	void OnResponseReloadServerConfig( const MUID& uidSender, const string& strFileList );
	void OnRequestAddHashMapnResponseAddHashMap( const MUID& uidSender, const string& strNewHashValue );

public:
	char	m_strFileCrcDataPath[MFile::MaxPath];

	void InitLocator();

#ifdef USE_WEBSOCKET
	std::unique_ptr<WebSocketListener> WsListener;
#endif

	void OnInput(const std::string& Input);

#ifdef USE_WEBSOCKET
	// WebSocket event callback — mirrors MServer::RCPCallback but uses
	// WsListener's context map instead of NetIO's.
	void OnWsEvent(WebSocketListener& WsListener,
	               NetIO::IOOperation Op,
	               WebSocketListener::ConnectionHandle Handle,
	               const void* Data);
#endif

private:
	void InitConsoleCommands();

	std::unique_ptr<MLocator> Locator;

	struct ConsoleCommand
	{
		std::function<void()> Callback;
		int MinArgs = -1;
		int MaxArgs = -1;
		std::string Description;
		std::string Usage;
		std::string Help;
	};
	std::unordered_map<std::string, ConsoleCommand> ConsoleCommandMap;
};


#endif