#include "stdafx.h"
#include "MBMatchServer.h"
#include <iostream>
#include <atomic>
#include <csignal>
#include <curl/curl.h>
#include "MFile.h"
#include "MCrashDump.h"
#if !defined(WIN32) && !defined(__EMSCRIPTEN__)
#  if __has_include(<systemd/sd-daemon.h>)
#    include <systemd/sd-daemon.h>
#  else
     // systemd headers not available — provide a no-op stub
     static inline int sd_notify(int, const char*) { return 0; }
#  endif
#endif
#ifdef USE_WEBSOCKET
#include "MLocator.h"
#endif

static std::atomic<bool> g_running{true};
static void SigHandler(int) {
    if (!g_running) _exit(1); // second signal: force exit immediately
    g_running = false;
}

template <size_t size>
static bool GetLogFileName(char(&pszBuf)[size])
{
	if (!MFile::IsDir("Log"))
		MFile::CreateDir("Log");

	struct tm	tmTime = *localtime(&unmove(time(0)));

	char szFileName[MFile::MaxPath];

	int nFooter = 1;
	while (true) {
		sprintf_safe(szFileName, "Log/MatchLog_%02d-%02d-%02d-%d.txt",
			tmTime.tm_year + 1900, tmTime.tm_mon + 1, tmTime.tm_mday, nFooter);

		if (!MFile::IsFile(szFileName))
			break;

		nFooter++;
		if (nFooter > 100) return false;
	}
	strcpy_safe(pszBuf, szFileName);
	return true;
}


static std::mutex InputMutex;
static std::vector<std::string> InputQueue;
static std::atomic<bool> HasInput;

static void InputThreadProc()
{
	std::string Input;

	while (true)
	{
		Input.clear();
		std::getline(std::cin, Input);
		if (Input.empty())
			continue;
		{
			std::lock_guard<std::mutex> Lock{ InputMutex };
			InputQueue.emplace_back(Input);
			HasInput = true;
		}
	}
}

static void HandleInput(MBMatchServer& MatchServer)
{
	if (!HasInput)
		return;

	std::lock_guard<std::mutex> Lock{ InputMutex };

	for (auto&& Input : InputQueue)
		MatchServer.OnInput(Input);

	InputQueue.clear();
	HasInput = false;
}

int main(int argc, char** argv)
try
{
	char LogFileName[MFile::MaxPath];
	GetLogFileName(LogFileName);
	InitLog(MLOGSTYLE_DEBUGSTRING | MLOGSTYLE_FILE, LogFileName);

	void MatchServerCustomLog(const char*);
	CustomLog = MatchServerCustomLog;

	curl_global_init(CURL_GLOBAL_DEFAULT);

	MBMatchServer MatchServer;

	if (!MatchServer.Create(6000))
	{
		MLog("MMatchServer::Create failed\n");
		return -1;
	}

	signal(SIGINT,  SigHandler);
	signal(SIGTERM, SigHandler);

	MatchServer.InitLocator();

#ifdef USE_WEBSOCKET
	{
		constexpr uint16_t WS_PORT  = 6032;
		constexpr uint16_t UDP_PORT = 8900;

		auto WsListener = std::make_unique<WebSocketListener>();
		WebSocketListener* pWsListener = WsListener.get();

		// TCP callback: forward WebSocket 0x01 frames to MBMatchServer.
		// On disconnect, also remove any UDP locator registration for this handle.
		WebSocketListener::CallbackType tcpCb =
			[&MatchServer, pWsListener](NetIO::IOOperation op,
			               WebSocketListener::ConnectionHandle hdl,
			               const void* data)
			{
				if (op == NetIO::IOOperation::Disconnect)
				{
					if (MLocator* pLoc = GetMainLocator())
						pLoc->UnregisterWsClient(hdl);
				}
				MatchServer.OnWsEvent(*pWsListener, op, hdl, data);
			};

		// UDP callback: forward WebSocket 0x02 frames to Locator.
		// 'handle'   — WebSocket connection that sent the frame.
		// 'srcIp'    — real peer IP of the WebSocket connection.
		// 'srcPort'  — synthetic per-connection port (ephemeral range).
		WebSocketListener::UdpCallbackType udpCb =
			[pWsListener](WebSocketListener::ConnectionHandle handle,
			              uint32_t srcIp, uint16_t srcPort,
			              const char* pkt, uint32_t size)
			{
				// Register the client so ResponseServerStatusInfoList can send
				// the response back over this WebSocket connection.
				if (MLocator* pLoc = GetMainLocator())
					pLoc->RegisterWsClient(srcIp, srcPort, handle);

				// MLocator::UDPSocketRecvEvent validates and dispatches to
				// GetMainLocator()->ParseUDPPacket().
				// srcPort is already in host-byte order; convert to network order
				// as UDPSocketRecvEvent re-converts with ntohs() internally.
				uint16_t rawPort = (MSocket::htons)(srcPort);
				MLocator::UDPSocketRecvEvent(
					srcIp, rawPort,
					const_cast<char*>(pkt), size);
			};

		if (!WsListener->Start(WS_PORT, std::move(tcpCb),
		                       std::move(udpCb), UDP_PORT))
		{
			MLog("WebSocketListener::Start failed on port %d\n", WS_PORT);
		}
		else
		{
			MLog("WebSocketListener started on port %d\n", WS_PORT);
			MatchServer.WsListener = std::move(WsListener);

			// Wire up the locator's WebSocket UDP sender so that
			// ResponseServerStatusInfoList routes responses back over WebSocket
			// instead of sending to the loopback UDP socket.
			if (MLocator* pLoc = GetMainLocator())
			{
				WebSocketListener* pWsl = MatchServer.WsListener.get();
				pLoc->SetWsSendUdpCallback(
					[pWsl](MLocator::WsHandle handle,
					       const void* data, uint32_t len)
					{
						// Wrap in a 0x02 frame with zero IP/port — the client
						// JS layer extracts the payload regardless of the header.
						pWsl->SendUDP(handle,
						              0, 0,
						              data, len);
					});
			}
		}
	}
#endif // USE_WEBSOCKET

	//std::thread{ [&] { InputThreadProc(); } }.detach();

#if !defined(WIN32) && !defined(__EMSCRIPTEN__)
	sd_notify(0, "READY=1");
#endif

	while (g_running)
	{
		MatchServer.Run();
		HandleInput(MatchServer);
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}

#ifdef USE_WEBSOCKET
	if (MatchServer.WsListener)
		MatchServer.WsListener->Stop();
#endif

	curl_global_cleanup();
}
catch (std::runtime_error& e)
{
	MLog("Uncaught std::runtime_error: %s\n", e.what());
	throw;
}