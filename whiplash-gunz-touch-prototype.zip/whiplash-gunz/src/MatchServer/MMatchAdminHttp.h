#pragma once
#include <thread>
#include <atomic>
#include <functional>
#include <string>
#include <map>
#include <utility>

struct AdminHttpRequest {
    std::string method;   // "GET", "POST", etc.
    std::string path;     // "/api/bounty/claim"
    std::string body;     // リクエストボディ (生文字列)
};

struct AdminHttpResponse {
    int         status;        // 200, 400, 401, 404 etc.
    std::string contentType;   // "application/json"
    std::string body;          // レスポンスボディ
};

using AdminRouteHandler = std::function<AdminHttpResponse(const AdminHttpRequest&)>;

class MMatchAdminHttp {
public:
    MMatchAdminHttp() = default;
    ~MMatchAdminHttp() { Stop(); }

    // ルート登録（Start() の前に呼ぶこと）
    void RegisterRoute(const std::string& method,
                       const std::string& path,
                       AdminRouteHandler handler);

    // HTTP リスナー起動
    // secretToken が空でなければ全エンドポイントで Bearer 認証を要求
    bool Start(int port, const char* secretToken);
    void Stop();

    bool IsRunning() const { return m_running.load(); }

private:
    void ListenLoop();
    void HandleClient(int clientFd);

    // "METHOD /path" をキーにしたルートマップ
    // 例: "POST /api/bounty/claim" → handler
    std::map<std::string, AdminRouteHandler> m_routes;

    int                  m_port{6034};
    std::string          m_secretToken;
    std::thread          m_thread;
    std::atomic<bool>    m_running{false};
    int                  m_serverFd{-1};
};
