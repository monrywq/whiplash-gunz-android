#include "stdafx.h"
#include "MAsyncDBJob_GoogleOAuth.h"
#include "GoogleTokenVerifier.h"
#include "MMatchConfig.h"
#include "IDatabase.h"
#include "sodium.h"
#include <cstdio>
#include <ctime>
#include <cstring>

static std::string GenerateUUID()
{
    unsigned char buf[16]{};
    FILE* f = fopen("/dev/urandom", "rb");
    if (f) { fread(buf, 1, 16, f); fclose(f); }
    buf[6] = (buf[6] & 0x0f) | 0x40; // version 4
    buf[8] = (buf[8] & 0x3f) | 0x80; // variant
    char uuid[37];
    snprintf(uuid, sizeof(uuid),
        "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
        buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7],
        buf[8], buf[9], buf[10], buf[11], buf[12], buf[13], buf[14], buf[15]);
    return uuid;
}

static std::string GenerateGoogleUserID(const std::string& sub)
{
    unsigned char digest[crypto_hash_sha256_BYTES]{};
    crypto_hash_sha256(
        digest,
        reinterpret_cast<const unsigned char*>(sub.data()),
        static_cast<unsigned long long>(sub.size()));

    constexpr size_t kUserIDHashBytes = 16;
    char encoded[sodium_base64_ENCODED_LEN(kUserIDHashBytes, sodium_base64_VARIANT_URLSAFE_NO_PADDING)]{};
    sodium_bin2base64(
        encoded,
        sizeof(encoded),
        digest,
        kUserIDHashBytes,
        sodium_base64_VARIANT_URLSAFE_NO_PADDING);

    return std::string("g_") + encoded;
}

void MAsyncDBJob_GoogleOAuth::Input(const MUID& CommUID, std::string IdToken,
    int CommandVersion, u32 ChecksumPack,
    u32 Major, u32 Minor, u32 Patch, u32 Revision,
    bool bFreeLoginIP, const std::string& strCountryCode3)
{
    m_CommUID         = CommUID;
    m_IdToken         = std::move(IdToken);
    m_CommandVersion  = CommandVersion;
    m_ChecksumPack    = ChecksumPack;
    m_Major           = Major;
    m_Minor           = Minor;
    m_Patch           = Patch;
    m_Revision        = Revision;
    m_bFreeLoginIP    = bFreeLoginIP;
    m_strCountryCode3 = strCountryCode3;
}

void MAsyncDBJob_GoogleOAuth::Run(void* pContext)
{
    auto* pDBMgr = static_cast<IDatabase*>(pContext);

    // Step 1: Verify Google token
    GoogleTokenClaims claims;
    std::string errMsg;

    if (!VerifyGoogleIdToken(m_IdToken, MGetServerConfig()->GoogleOAuthClientId, claims, errMsg))
    {
        ErrorMsg = errMsg;
        SetResult(MASYNC_RESULT_FAILED);
        return;
    }

    // Step 2: Look up AID by Google sub
    unsigned int aid = pDBMgr->GetAIDByGoogleSub(claims.sub.c_str());

    // Step 3: If not found, create an account
    if (aid == 0)
    {
        std::string username = GenerateGoogleUserID(claims.sub);
        aid = pDBMgr->CreateAccountForGoogle(claims.sub.c_str(), claims.email.c_str(), username.c_str());
    }

    if (aid == 0)
    {
        ErrorMsg = "Failed to create or find account for Google sub";
        SetResult(MASYNC_RESULT_FAILED);
        return;
    }

    // Step 4: Generate session token and store it
    std::string token = GenerateUUID();
    int64_t expiresAt = static_cast<int64_t>(time(nullptr)) + MGetServerConfig()->SessionExpirySec;

    if (!pDBMgr->CreateSession(token.c_str(), aid, expiresAt))
    {
        ErrorMsg = "Failed to create session";
        SetResult(MASYNC_RESULT_FAILED);
        return;
    }

    // Step 5: Clean up old sessions
    pDBMgr->CleanExpiredSessions();

    // Fill output
    Verified         = true;
    AID              = aid;
    SessionToken     = std::move(token);
    SessionExpiresAt = expiresAt;

    SetResult(MASYNC_RESULT_SUCCEED);
}
