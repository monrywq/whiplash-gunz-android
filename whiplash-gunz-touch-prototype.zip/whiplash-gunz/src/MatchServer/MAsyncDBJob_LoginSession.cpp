#include "stdafx.h"
#include "MAsyncDBJob_LoginSession.h"
#include "MMatchConfig.h"
#include "IDatabase.h"
#include <cstdio>
#include <ctime>

static std::string GenerateSessionUUID()
{
    unsigned char buf[16]{};
    FILE* f = fopen("/dev/urandom", "rb");
    if (f) { fread(buf, 1, 16, f); fclose(f); }
    buf[6] = (buf[6] & 0x0f) | 0x40; // version 4
    buf[8] = (buf[8] & 0x3f) | 0x80; // variant
    char uuid[37];
    snprintf(uuid, sizeof(uuid),
        "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
        buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7],
        buf[8], buf[9], buf[10], buf[11], buf[12], buf[13], buf[14], buf[15]);
    return uuid;
}

void MAsyncDBJob_LoginSession::Input(const MUID& CommUID, std::string SessionToken,
    int CommandVersion, u32 ChecksumPack,
    u32 Major, u32 Minor, u32 Patch, u32 Revision,
    bool bFreeLoginIP, const std::string& strCountryCode3)
{
    m_CommUID         = CommUID;
    m_SessionToken    = std::move(SessionToken);
    m_CommandVersion  = CommandVersion;
    m_ChecksumPack    = ChecksumPack;
    m_Major           = Major;
    m_Minor           = Minor;
    m_Patch           = Patch;
    m_Revision        = Revision;
    m_bFreeLoginIP    = bFreeLoginIP;
    m_strCountryCode3 = strCountryCode3;
}

void MAsyncDBJob_LoginSession::Run(void* pContext)
{
    auto* pDBMgr = static_cast<IDatabase*>(pContext);

    // Look up AID from session (returns 0 if expired or not found)
    unsigned int aid = pDBMgr->GetAIDBySession(m_SessionToken.c_str());

    if (aid == 0)
    {
        ErrorMsg = "Session expired or invalid";
        SetResult(MASYNC_RESULT_FAILED);
        return;
    }

    // Rolling renewal: delete old session and create a new one
    pDBMgr->DeleteSession(m_SessionToken.c_str());

    std::string newToken = GenerateSessionUUID();
    int64_t expiresAt = static_cast<int64_t>(time(nullptr)) + MGetServerConfig()->SessionExpirySec;

    pDBMgr->CreateSession(newToken.c_str(), aid, expiresAt);

    // Fill output
    AID                 = aid;
    NewSessionToken     = std::move(newToken);
    NewSessionExpiresAt = expiresAt;

    SetResult(MASYNC_RESULT_SUCCEED);
}
