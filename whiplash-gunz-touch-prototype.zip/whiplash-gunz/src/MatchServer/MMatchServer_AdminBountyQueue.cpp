#include "stdafx.h"
#include "MMatchServer.h"

#include <utility>

namespace {

constexpr size_t kMaxAdminBountyClaimQueueSize = 64;
constexpr size_t kMaxAdminBountyClaimsPerTick = 4;

AdminBountyClaimResult MakeAdminBountyClaimFailure(const char* reason)
{
	AdminBountyClaimResult result;
	result.ok = false;
	result.reason = reason ? reason : "";
	return result;
}

} // namespace

std::future<AdminBountyClaimResult> MMatchServer::QueueAdminBountyClaim(AdminBountyClaimRequest request)
{
	AdminBountyClaimQueueItem item;
	item.request = std::move(request);

	std::future<AdminBountyClaimResult> future = item.promise.get_future();

	{
		std::lock_guard<std::mutex> lock(m_adminBountyClaimQueueMutex);
		if (m_adminBountyClaimStopping)
		{
			item.promise.set_value(MakeAdminBountyClaimFailure("stopping"));
			return future;
		}

		if (m_adminBountyClaimQueue.size() >= kMaxAdminBountyClaimQueueSize)
		{
			item.promise.set_value(MakeAdminBountyClaimFailure("server busy"));
			return future;
		}

		m_adminBountyClaimQueue.push(std::move(item));
	}

	return future;
}

void MMatchServer::RejectAdminBountyClaimQueue()
{
	std::queue<AdminBountyClaimQueueItem> pending;

	{
		std::lock_guard<std::mutex> lock(m_adminBountyClaimQueueMutex);
		m_adminBountyClaimStopping = true;
		pending.swap(m_adminBountyClaimQueue);
	}

	while (!pending.empty())
	{
		AdminBountyClaimQueueItem item = std::move(pending.front());
		pending.pop();
		item.promise.set_value(MakeAdminBountyClaimFailure("stopping"));
	}
}

void MMatchServer::ProcessAdminBountyClaimQueue()
{
	for (size_t processed = 0; processed < kMaxAdminBountyClaimsPerTick; ++processed)
	{
		AdminBountyClaimQueueItem item;

		{
			std::lock_guard<std::mutex> lock(m_adminBountyClaimQueueMutex);
			if (m_adminBountyClaimQueue.empty())
				return;

			item = std::move(m_adminBountyClaimQueue.front());
			m_adminBountyClaimQueue.pop();
		}

		AdminBountyClaimResult result;
		if (item.request.code.empty())
		{
			result.ok = false;
			result.reason = "missing code";
			item.promise.set_value(std::move(result));
			continue;
		}

		result.ok = GrantDailyBountyByCode(item.request.code.c_str(),
			item.request.discordUserID.c_str(),
			result.charName,
			result.bpGranted);
		if (!result.ok)
			result.reason = "code invalid, expired, or already claimed";

		item.promise.set_value(std::move(result));
	}
}
