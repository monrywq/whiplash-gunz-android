#include "stdafx.h"
#include "MMatchAdminHttp.h"
#include "MDebug.h"
#include <cstring>
#include <cstdio>

#ifdef _WIN32
#  include <winsock2.h>
#  pragma comment(lib, "ws2_32.lib")
using socket_t = SOCKET;
#  define CLOSE_SOCKET(s) closesocket(s)
#  define SOCK_ERR        SOCKET_ERROR
#  define INVALID_SOCK    INVALID_SOCKET
#  define SOCKET_SHUTDOWN_BOTH SD_BOTH
static inline bool SocketValid(socket_t s) { return s != INVALID_SOCKET; }
#else
#  include <sys/socket.h>
#  include <sys/select.h>
#  include <netinet/in.h>
#  include <unistd.h>
#  include <cerrno>
using socket_t = int;
#  define CLOSE_SOCKET(s) ::close(s)
#  define SOCK_ERR        (-1)
#  define INVALID_SOCK    (-1)
#  define SOCKET_SHUTDOWN_BOTH SHUT_RDWR
static inline bool SocketValid(socket_t s) { return s >= 0; }
#endif

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
namespace {

static const char* StatusLine(int status)
{
    switch (status)
    {
    case 200: return "200 OK";
    case 400: return "400 Bad Request";
    case 401: return "401 Unauthorized";
    case 403: return "403 Forbidden";
    case 404: return "404 Not Found";
    case 500: return "500 Internal Server Error";
    case 503: return "503 Service Unavailable";
    case 504: return "504 Gateway Timeout";
    default:  return "200 OK";
    }
}

static std::string BuildHttpResponse(const AdminHttpResponse& res)
{
    char header[512];
    snprintf(header, sizeof(header),
        "HTTP/1.1 %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %d\r\n\r\n",
        StatusLine(res.status),
        res.contentType.c_str(),
        static_cast<int>(res.body.size()));

    return std::string(header) + res.body;
}

} // anonymous namespace

// ---------------------------------------------------------------------------
// RegisterRoute
// ---------------------------------------------------------------------------
void MMatchAdminHttp::RegisterRoute(const std::string& method,
                                     const std::string& path,
                                     AdminRouteHandler handler)
{
    std::string key = method + " " + path;
    m_routes[key] = std::move(handler);
}

// ---------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------
bool MMatchAdminHttp::Start(int port, const char* secretToken)
{
    if (m_running.load()) return true;

    m_port        = port;
    m_secretToken = secretToken ? secretToken : "";
    m_running     = true;

    m_thread = std::thread([this] { ListenLoop(); });

    MLog("MMatchAdminHttp: listening on port %d\n", m_port);
    return true;
}

// ---------------------------------------------------------------------------
// Stop
// ---------------------------------------------------------------------------
void MMatchAdminHttp::Stop()
{
    if (!m_running.exchange(false) && !m_thread.joinable()) return;

    if (SocketValid(m_serverFd))
    {
        shutdown(static_cast<socket_t>(m_serverFd), SOCKET_SHUTDOWN_BOTH);
        CLOSE_SOCKET(m_serverFd);
        m_serverFd = INVALID_SOCK;
    }

    if (m_thread.joinable())
        m_thread.join();
}

// ---------------------------------------------------------------------------
// ListenLoop  (runs in its own thread)
// ---------------------------------------------------------------------------
void MMatchAdminHttp::ListenLoop()
{
    socket_t serverFd = ::socket(AF_INET, SOCK_STREAM, 0);
    if (!SocketValid(serverFd))
    {
        MLog("MMatchAdminHttp: socket() failed\n");
        m_running = false;
        m_serverFd = INVALID_SOCK;
        return;
    }

    m_serverFd = static_cast<int>(serverFd);

    int opt = 1;
    setsockopt(serverFd, SOL_SOCKET, SO_REUSEADDR,
               reinterpret_cast<const char*>(&opt), sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons(static_cast<uint16_t>(m_port));

    if (::bind(serverFd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCK_ERR)
    {
        MLog("MMatchAdminHttp: bind() failed on port %d\n", m_port);
        CLOSE_SOCKET(serverFd);
        m_running = false;
        m_serverFd = INVALID_SOCK;
        return;
    }

    if (::listen(serverFd, 8) == SOCK_ERR)
    {
        MLog("MMatchAdminHttp: listen() failed\n");
        CLOSE_SOCKET(serverFd);
        m_running = false;
        m_serverFd = INVALID_SOCK;
        return;
    }

    while (m_running.load())
    {
        fd_set readSet;
        FD_ZERO(&readSet);
        FD_SET(serverFd, &readSet);

        timeval timeout{};
        timeout.tv_sec = 1;

        int ready = select(static_cast<int>(serverFd) + 1, &readSet, nullptr, nullptr, &timeout);
        if (ready == 0)
            continue;
        if (ready < 0)
            break;

        socket_t clientFd = ::accept(serverFd, nullptr, nullptr);
        if (!SocketValid(clientFd))
        {
            // accept() unblocked because the server socket was closed in Stop()
            break;
        }

        HandleClient(static_cast<int>(clientFd));
        CLOSE_SOCKET(clientFd);
    }

    // Server socket may already be closed by Stop(); close it only if still open.
    if (SocketValid(serverFd) && static_cast<int>(serverFd) == m_serverFd)
    {
        CLOSE_SOCKET(serverFd);
        m_serverFd = INVALID_SOCK;
    }
}

// ---------------------------------------------------------------------------
// HandleClient
// ---------------------------------------------------------------------------
void MMatchAdminHttp::HandleClient(int clientFd)
{
#ifdef _WIN32
    DWORD timeoutMs = 5000;
    setsockopt(static_cast<socket_t>(clientFd), SOL_SOCKET, SO_RCVTIMEO,
               reinterpret_cast<const char*>(&timeoutMs), sizeof(timeoutMs));
#else
    timeval timeout{};
    timeout.tv_sec = 5;
    setsockopt(static_cast<socket_t>(clientFd), SOL_SOCKET, SO_RCVTIMEO,
               reinterpret_cast<const char*>(&timeout), sizeof(timeout));
#endif

    char buf[4096]{};
    int received = static_cast<int>(
        recv(static_cast<socket_t>(clientFd), buf, sizeof(buf) - 1, 0));

    if (received <= 0) return;
    buf[received] = '\0';

    std::string request(buf, static_cast<size_t>(received));

    // Parse request line: "METHOD /path HTTP/1.1"
    std::string method, path;
    {
        auto lineEnd = request.find("\r\n");
        std::string requestLine = (lineEnd != std::string::npos)
                                  ? request.substr(0, lineEnd)
                                  : request;

        auto sp1 = requestLine.find(' ');
        if (sp1 != std::string::npos)
        {
            method = requestLine.substr(0, sp1);
            auto sp2 = requestLine.find(' ', sp1 + 1);
            if (sp2 != std::string::npos)
                path = requestLine.substr(sp1 + 1, sp2 - sp1 - 1);
            else
                path = requestLine.substr(sp1 + 1);
        }
    }

    // Validate Authorization header
    if (!m_secretToken.empty())
    {
        std::string needle = "Authorization: Bearer ";
        auto authPos = request.find(needle);
        bool authorized = false;
        if (authPos != std::string::npos)
        {
            auto tokenStart = authPos + needle.size();
            auto tokenEnd   = request.find("\r\n", tokenStart);
            if (tokenEnd != std::string::npos)
            {
                std::string token = request.substr(tokenStart, tokenEnd - tokenStart);
                authorized = (token == m_secretToken);
            }
        }

        if (!authorized)
        {
            const char* unauth =
                "HTTP/1.1 401 Unauthorized\r\nContent-Length: 0\r\n\r\n";
            send(static_cast<socket_t>(clientFd), unauth,
                 static_cast<int>(strlen(unauth)), 0);
            return;
        }
    }

    // Look up route
    std::string routeKey = method + " " + path;
    auto it = m_routes.find(routeKey);
    if (it == m_routes.end())
    {
        const char* notFound =
            "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
        send(static_cast<socket_t>(clientFd), notFound,
             static_cast<int>(strlen(notFound)), 0);
        return;
    }

    // Extract body (everything after \r\n\r\n)
    std::string body;
    auto sepPos = request.find("\r\n\r\n");
    if (sepPos != std::string::npos)
        body = request.substr(sepPos + 4);

    // Build request and call handler
    AdminHttpRequest req;
    req.method = method;
    req.path   = path;
    req.body   = body;

    AdminHttpResponse res = it->second(req);

    std::string response = BuildHttpResponse(res);
    send(static_cast<socket_t>(clientFd), response.c_str(),
         static_cast<int>(response.size()), 0);
}
