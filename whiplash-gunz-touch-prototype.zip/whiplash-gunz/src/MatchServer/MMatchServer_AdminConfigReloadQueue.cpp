#include "stdafx.h"
#include "MMatchServer.h"
#include "MMatchConfig.h"

#include <utility>

namespace {

constexpr size_t kMaxAdminConfigReloadQueueSize = 16;
constexpr size_t kMaxAdminConfigReloadsPerTick = 1;

AdminConfigReloadResult MakeAdminConfigReloadFailure(const char* reason)
{
	AdminConfigReloadResult result;
	result.ok = false;
	result.reason = reason ? reason : "";
	return result;
}

} // namespace

std::future<AdminConfigReloadResult> MMatchServer::QueueAdminConfigReload(AdminConfigReloadRequest request)
{
	AdminConfigReloadQueueItem item;
	item.request = std::move(request);

	std::future<AdminConfigReloadResult> future = item.promise.get_future();

	{
		std::lock_guard<std::mutex> lock(m_adminConfigReloadQueueMutex);
		if (m_adminConfigReloadStopping)
		{
			item.promise.set_value(MakeAdminConfigReloadFailure("stopping"));
			return future;
		}

		if (m_adminConfigReloadQueue.size() >= kMaxAdminConfigReloadQueueSize)
		{
			item.promise.set_value(MakeAdminConfigReloadFailure("server busy"));
			return future;
		}

		m_adminConfigReloadQueue.push(std::move(item));
	}

	return future;
}

void MMatchServer::RejectAdminConfigReloadQueue()
{
	std::queue<AdminConfigReloadQueueItem> pending;

	{
		std::lock_guard<std::mutex> lock(m_adminConfigReloadQueueMutex);
		m_adminConfigReloadStopping = true;
		pending.swap(m_adminConfigReloadQueue);
	}

	while (!pending.empty())
	{
		AdminConfigReloadQueueItem item = std::move(pending.front());
		pending.pop();
		item.promise.set_value(MakeAdminConfigReloadFailure("stopping"));
	}
}

void MMatchServer::ProcessAdminConfigReloadQueue()
{
	for (size_t processed = 0; processed < kMaxAdminConfigReloadsPerTick; ++processed)
	{
		AdminConfigReloadQueueItem item;

		{
			std::lock_guard<std::mutex> lock(m_adminConfigReloadQueueMutex);
			if (m_adminConfigReloadQueue.empty())
				return;

			item = std::move(m_adminConfigReloadQueue.front());
			m_adminConfigReloadQueue.pop();
		}

		AdminConfigReloadResult result;
		if (item.request.fileNames.size() != 1 || item.request.fileNames.front() != "server.ini")
		{
			result.ok = false;
			result.reason = "unsupported file";
			item.promise.set_value(std::move(result));
			continue;
		}

		std::string reason;
		result.ok = OnAdminReloadConfig(item.request.fileNames, reason);
		if (result.ok)
		{
			SetRegistrationSecret(MGetServerConfig()->RegistrationSecret.c_str());
		}
		else
		{
			result.reason = reason.empty() ? "reload failed" : std::move(reason);
		}

		item.promise.set_value(std::move(result));
	}
}
