#include "stdafx.h"
#include "MMatchServer.h"
#include "MMatchObject.h"
#include "MMatchConfig.h"
#include "MSharedCommandTable.h"
#include "MCommandParameter.h"
#include "IDatabase.h"
#include <random>
#include <ctime>
#include <cstdio>
#include <string>

static constexpr int64_t kDailyBountyDaySeconds = 86400;

static int GetDailyBountyClaimDay(int64_t unixTime)
{
	return static_cast<int>(unixTime / kDailyBountyDaySeconds);
}

// ---------------------------------------------------------------------------
// GenerateBountyCode
// Returns a code of the form "WHIP-XXXXXXXXXXXX" where X is uppercase hex.
// ---------------------------------------------------------------------------
static std::string GenerateBountyCode()
{
	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_int_distribution<int> dist(0, 255);

	char buf[sizeof("WHIP-FFFFFFFFFFFF")];
	snprintf(buf, sizeof(buf), "WHIP-%02X%02X%02X%02X%02X%02X",
		dist(gen), dist(gen), dist(gen),
		dist(gen), dist(gen), dist(gen));
	return buf;
}

// ---------------------------------------------------------------------------
// SendDailyBountyResponse
// ---------------------------------------------------------------------------
void MMatchServer::SendDailyBountyResponse(const MUID& uidPlayer,
	int result, const char* code, int expiresInSec, int bpAmount)
{
	MCommand* pCmd = CreateCommand(MC_MATCH_DAILY_BOUNTY_RESPONSE, uidPlayer);
	if (!pCmd) return;

	pCmd->AddParameter(new MCommandParameterInt(result));
	pCmd->AddParameter(new MCommandParameterString(code ? code : ""));
	pCmd->AddParameter(new MCommandParameterInt(expiresInSec));
	pCmd->AddParameter(new MCommandParameterInt(bpAmount));
	Post(pCmd);
}

// ---------------------------------------------------------------------------
// OnDailyBountyRequest  (called from the main game-loop thread)
// ---------------------------------------------------------------------------
void MMatchServer::OnDailyBountyRequest(const MUID& uidPlayer)
{
	MMatchObject* pObj = GetObject(uidPlayer);
	if (!pObj)
		return;

	// Player must be logged in with a character
	MMatchCharInfo* pCharInfo = pObj->GetCharInfo();
	if (!pCharInfo)
	{
		SendDailyBountyResponse(uidPlayer, 2, "", 0, 0);
		return;
	}

	int AID = pObj->GetAccountInfo()->m_nAID;
	int CID = static_cast<int>(pCharInfo->m_nCID);
	const char* charName = pCharInfo->m_szName;
	int64_t now = static_cast<int64_t>(time(nullptr));
	int claimDay = GetDailyBountyClaimDay(now);
	int expirySec = MGetServerConfig()->GetDailyBountyExpirySec();
	int bpAmount = MGetServerConfig()->GetDailyBountyBP();

	bool bAlreadyClaimed = false;
	if (!GetDBMgr()->HasDailyBountyClaimedByCIDDay(CID, claimDay, bAlreadyClaimed))
	{
		MLog("OnDailyBountyRequest: DB error checking daily claim for CID=%d\n", CID);
		SendDailyBountyResponse(uidPlayer, 2, "", 0, 0);
		return;
	}

	if (bAlreadyClaimed)
	{
		// Result 1 = already claimed today
		SendDailyBountyResponse(uidPlayer, 1, "", 0, 0);
		return;
	}

	DailyBountyRecord rec;
	bool bFoundExisting = false;
	if (!GetDBMgr()->GetDailyBountyByCIDDay(CID, claimDay, rec, bFoundExisting))
	{
		MLog("OnDailyBountyRequest: DB error loading daily bounty for CID=%d\n", CID);
		SendDailyBountyResponse(uidPlayer, 2, "", 0, 0);
		return;
	}

	if (bFoundExisting)
	{
		if (rec.ClaimedAt != 0)
		{
			SendDailyBountyResponse(uidPlayer, 1, "", 0, 0);
			return;
		}

		if (rec.ExpiresAt > now)
		{
			int expiresInSec = static_cast<int>(rec.ExpiresAt - now);
			MLog("OnDailyBountyRequest: reused code %s for %s (AID=%d, CID=%d)\n",
				rec.code, charName, AID, CID);
			SendDailyBountyResponse(uidPlayer, 0, rec.code, expiresInSec, bpAmount);
			return;
		}

		std::string code = GenerateBountyCode();
		int64_t expiresAt = now + expirySec;

		if (!GetDBMgr()->RefreshDailyBounty(rec.id, code.c_str(), AID, CID,
			charName, expiresAt, claimDay))
		{
			MLog("OnDailyBountyRequest: DB error refreshing bounty code for CID=%d\n", CID);
			SendDailyBountyResponse(uidPlayer, 2, "", 0, 0);
			return;
		}

		MLog("OnDailyBountyRequest: refreshed code %s for %s (AID=%d, CID=%d)\n",
			code.c_str(), charName, AID, CID);
		SendDailyBountyResponse(uidPlayer, 0, code.c_str(), expirySec, bpAmount);
		return;
	}

	std::string code = GenerateBountyCode();
	int64_t expiresAt = now + expirySec;

	if (!GetDBMgr()->InsertDailyBounty(code.c_str(), AID, CID, charName, expiresAt, claimDay))
	{
		MLog("OnDailyBountyRequest: DB error inserting bounty code for CID=%d\n", CID);
		SendDailyBountyResponse(uidPlayer, 2, "", 0, 0);
		return;
	}

	MLog("OnDailyBountyRequest: generated code %s for %s (AID=%d, CID=%d)\n",
		code.c_str(), charName, AID, CID);

	// Result 0 = success
	SendDailyBountyResponse(uidPlayer, 0, code.c_str(), expirySec, bpAmount);
}

void MMatchServer::OnDailyBountyAutoIssue(const MUID& uidPlayer)
{
	MMatchObject* pObj = GetObject(uidPlayer);
	if (!pObj || !pObj->GetCharInfo())
		return;

	int CID = static_cast<int>(pObj->GetCharInfo()->m_nCID);
	int claimDay = GetDailyBountyClaimDay(static_cast<int64_t>(time(nullptr)));
	bool bAlreadyClaimed = false;
	if (!GetDBMgr()->HasDailyBountyClaimedByCIDDay(CID, claimDay, bAlreadyClaimed))
	{
		MLog("OnDailyBountyAutoIssue: DB error checking daily claim for CID=%d\n", CID);
		return;
	}

	if (bAlreadyClaimed)
		return;

	OnDailyBountyRequest(uidPlayer);
}

// ---------------------------------------------------------------------------
// GrantDailyBountyByCode  (called from the match server run loop)
// ---------------------------------------------------------------------------
bool MMatchServer::GrantDailyBountyByCode(const char* code, const char* discordUID,
	std::string& outCharName, int& outBPGranted)
{
	int64_t now = static_cast<int64_t>(time(nullptr));
	int bpAmt = MGetServerConfig()->GetDailyBountyBP();
	DailyBountyRecord rec;
	if (!GetDBMgr()->ClaimDailyBountyByCode(code, now, bpAmt, discordUID, rec))
	{
		MLog("GrantDailyBountyByCode: claim failed for code=%s\n", code);
		return false;
	}

	// If the player is currently online, update their in-memory BP and notify them
	for (auto& pair : *GetObjects())
	{
		MMatchObject* pObj = static_cast<MMatchObject*>(pair.second);
		if (!pObj) continue;
		MMatchCharInfo* pCI = pObj->GetCharInfo();
		if (!pCI) continue;
		if (static_cast<int>(pCI->m_nCID) != rec.CID) continue;

		// Update in-memory BP
		pCI->IncBP(bpAmt);

		// Send an announcement to the player
		char szMsg[256];
		snprintf(szMsg, sizeof(szMsg),
			"Discord Daily Bounty claimed! +%d BP has been added to your account.", bpAmt);
		Announce(pObj, szMsg);
		break;
	}

	outCharName  = rec.CharName;
	outBPGranted = bpAmt;

	MLog("GrantDailyBountyByCode: granted %d BP to %s (CID=%d) via Discord UID %s\n",
		bpAmt, rec.CharName, rec.CID, discordUID ? discordUID : "(none)");

	return true;
}
