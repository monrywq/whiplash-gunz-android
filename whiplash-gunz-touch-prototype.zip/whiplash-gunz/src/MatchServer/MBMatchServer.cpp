#include "stdafx.h"
#include "MBMatchServer.h"
#ifdef USE_WEBSOCKET
#include "MCommandBuilder.h"
#include "MPacket.h"
#endif
#ifdef MFC
#include "MatchServerDoc.h"
#include "OutputView.h"
#include "MatchServer.h"
#include "CommandLogView.h"
#include <atltime.h>
#endif
#include "MErrorTable.h"
#include "MDebug.h"
#include "MMatchRule.h"
#include "MDebug.h"
#include "MMatchStatus.h"
#include "MMatchSchedule.h"
#include "MSharedCommandTable.h"
#include "MMatchConfig.h"
#include "MMatchEventFactory.h"
#include "MMatchLocale.h"
#pragma comment(lib, "comsupp.lib")

#if defined(_DEBUG) && defined(MFC)
#define new DEBUG_NEW
#endif

bool MBMatchServer::OnCreate(void)
{
	if( !MMatchServer::OnCreate() )
		return false;

	if( !m_ConfigReloader.Create() )
		return false;

	WriteServerInfoLog();

	InitConsoleCommands();

	return true;
}

void MBMatchServer::OnDestroy(void)
{
}

void MBMatchServer::OnPrepareCommand(MCommand* pCommand)
{
#if defined(_DEBUG) && defined(MFC)
#ifndef _DEBUG_PUBLISH
	// 커맨드 로그 남기기
	if(m_pCmdLogView==NULL) return;

	CMatchServerApp* pApp = (CMatchServerApp*)AfxGetApp();
	if (pApp->CheckOutputLog() == false) return;


	CCommandLogView::CCommandType t;
	if(pCommand->m_pCommandDesc->IsFlag(MCDT_LOCAL)==true) t = CCommandLogView::CCT_LOCAL;
	else if(pCommand->m_Sender==m_This) t = CCommandLogView::CCT_SEND;
	else if(pCommand->m_Receiver==m_This) t = CCommandLogView::CCT_RECEIVE;
	else _ASSERT(FALSE);
	
	m_pCmdLogView->AddCommand(GetGlobalClockCount(), t, pCommand);
#endif
#endif
}



MBMatchServer::MBMatchServer(COutputView* pView)
{
#ifdef MFC
	m_pView = pView;
	m_pCmdLogView = NULL;
#endif
	
	SetKeeperUID( MUID(0, 0) );
}

void MBMatchServer::Shutdown()
{
	MMatchServer::Shutdown();
#ifdef MFC
	AfxGetMainWnd()->PostMessage(WM_DESTROY);
#endif
}

static void MBMatchServerLog(unsigned int LogLevel, const char* Msg, bool Newline)
{
	static std::mutex LogMutex;
	std::lock_guard<std::mutex> Lock(LogMutex);

	char Str[1024 * 16];
	ArrayView<char> Remaining = Str;
	auto Consumed = strftime(Str, sizeof(Str), "%FT%T%z", localtime(&unmove(time(0))));
	if (!Consumed)
	{
		assert(false);
		return;
	}
	Remaining.remove_prefix(Consumed);
	auto Append = [&](const char* a) {
		auto Zero = strcpy_safe(Remaining, a);
		Remaining.remove_prefix(Zero - Remaining.data());
	};
	Append(" | ");
	Append(Msg);
	Append(Newline ? "\n" : "");

	fputs(Str, stdout);
	fflush(stdout);

	if (LogLevel & MMatchServer::LOG_FILE)
		MLogFile(Str);

#ifdef _DEBUG
	if (LogLevel & MMatchServer::LOG_DEBUG)
	{
		OutputDebugString(Msg);
		if (Newline)
			OutputDebugString("\n");
	}
#endif

}

void MBMatchServer::Log(unsigned int LogLevel, const char* Msg)
{
	MBMatchServerLog(LogLevel, Msg, true);
}

bool MBMatchServer::OnAdminReloadConfig(const std::vector<std::string>& fileNames,
	std::string& outError)
{
	if (fileNames.size() != 1 || !iequals(fileNames.front(), "server.ini"))
	{
		outError = "only server.ini reload is supported";
		return false;
	}

	MMatchConfig* const activeConfig = MGetServerConfig();
	MMatchConfig previousConfig = *activeConfig;

	MMatchConfig reloadedConfig = previousConfig;
	reloadedConfig.Clear();
	if (!reloadedConfig.Create())
	{
		outError = "failed to reload server.ini";
		return false;
	}

	if (strcmp(previousConfig.GetAdminApiSecret(), reloadedConfig.GetAdminApiSecret()) != 0)
	{
		outError = "admin HTTP secret change requires restart";
		mlog("MBMatchServer::OnAdminReloadConfig - rejected server.ini reload because admin HTTP secret changed\n");
		return false;
	}

	if (previousConfig.GetAdminHttpPort() != reloadedConfig.GetAdminHttpPort())
	{
		outError = "admin HTTP port change requires restart";
		mlog("MBMatchServer::OnAdminReloadConfig - rejected server.ini reload because admin HTTP port changed\n");
		return false;
	}

	reloadedConfig.SetEnabledCreateLadderGame(previousConfig.IsEnabledCreateLadderGame());
	*activeConfig = reloadedConfig;

	std::string refreshError;
	if (!RefreshRuntimeConfigState(refreshError))
	{
		*activeConfig = previousConfig;

		std::string rollbackError;
		if (!RefreshRuntimeConfigState(rollbackError))
		{
			mlog("MBMatchServer::OnAdminReloadConfig - failed to restore runtime state after reload error: %s\n",
				rollbackError.c_str());
		}

		outError = refreshError.empty() ? "failed to refresh runtime state after reload" : refreshError;
		mlog("MBMatchServer::OnAdminReloadConfig - failed to apply runtime state for %s: %s\n",
			fileNames.front().c_str(), outError.c_str());
		return false;
	}

	outError.clear();
	mlog("MBMatchServer::OnAdminReloadConfig - reloaded %s\n", fileNames.front().c_str());
	return true;
}

bool MBMatchServer::InitSubTaskSchedule()
{
	if( ( MSM_CLAN == MGetServerConfig()->GetServerMode() ) || MSM_TEST == MGetServerConfig()->GetServerMode() ){
		if( !AddClanServerSwitchDownSchedule() )
			return false;

		if( !AddClanServerAnnounceSchedule() )
		return false;
	}

	return true;
}

bool MBMatchServer::AddClanServerSwitchDownSchedule()
{
	int a = 0;

	MCommand* pCmd = CreateCommand( MC_MATCH_SCHEDULE_CLAN_SERVER_SWITCH_DOWN, MUID(0, 0) );
	if( 0 == pCmd )
		return false;

	tm t;
	MMatchGetLocalTime(&t);

	MMatchScheduleData* pScheduleData = m_pScheduler->MakeOnceScheduleData( t.tm_year - 100, t.tm_mon + 1, GetMaxDay(), 23, 50, pCmd );
	if( 0 == pScheduleData ){
		delete pCmd;
		return false;
	}

	if( !m_pScheduler->AddDynamicSchedule(pScheduleData) ){
		delete pCmd;
		delete pScheduleData;
		return false;
	}

	mlog( "MBMatchServer::AddClanServerSwitchDownSchedule - 클랜서버다운 커맨드 생성 성공. 다음실행시간:%d년%d월%d일 %d시%d분\n",
		pScheduleData->GetYear(), pScheduleData->GetMonth(), pScheduleData->GetDay(),
		pScheduleData->GetHour(), pScheduleData->GetMin() );

	return true;
}


bool MBMatchServer::AddClanServerSwitchUpSchedule()
{
	MCommand* pCmd = CreateCommand( MC_MATCH_SCHEDULE_CLAN_SERVER_SWITCH_ON, MUID(0, 0) );
	if( 0 == pCmd )
	{
		mlog( "MBMatchServer::AddClanServerSwitchUpSchedule - 클랜섭 활성화 커맨드 생성 실패.\n" );
		return false;
	}

	tm t;
	MMatchGetLocalTime(&t);

	unsigned char cYear;
	unsigned char cMon;

	if( 12 >= (t.tm_mon + 2) )
	{
		cYear = t.tm_year - 100;
		cMon  = t.tm_mon + 2;
	}
	else
	{
		cYear = t.tm_year - 99;
		cMon  = 1;
	}

	MMatchScheduleData* pScheduleData = m_pScheduler->MakeOnceScheduleData( cYear, cMon, 1, 9, 0, pCmd );
	if( 0 == pScheduleData )
	{
		delete pCmd;
		return false;
	}

	if( !m_pScheduler->AddDynamicSchedule(pScheduleData) )
	{
		delete pCmd;
		delete pScheduleData;
		return false;
	}

	mlog( "MBMatchServer::AddClanServerSwitchUpSchedule - 클랜서버업 커맨드 생성 성공. 다음실행시간:%d년%d월%d일 %d시%d분\n",
		pScheduleData->GetYear(), pScheduleData->GetMonth(), pScheduleData->GetDay(),
		pScheduleData->GetHour(), pScheduleData->GetMin() );

	return true;
}

bool MBMatchServer::AddClanServerAnnounceSchedule()
{
	char szTest[] = "클랜전 게임을 11시 50분에 닫도록 하겠습니다.";

	MCommand* pCmd = CreateCommand( MC_MATCH_SCHEDULE_ANNOUNCE_MAKE, MUID(0, 0) );
	if( 0 == pCmd )
		return false;

	MCommandParameterString* pCmdPrmStr = new MCommandParameterString( szTest );
	if( 0 == pCmdPrmStr ){
		delete pCmd;
		return false;
	}
	
	if( !pCmd->AddParameter(pCmdPrmStr) ){
		delete pCmd;
		return false;
	}

	tm t;
	MMatchGetLocalTime(&t);

	MMatchScheduleData* pScheduleData = m_pScheduler->MakeOnceScheduleData( t.tm_year - 100, t.tm_mon + 1, GetMaxDay(), 23, 40, pCmd );
	if( 0 == pScheduleData ){
		delete pCmd;
		return false;
	}

	if( !m_pScheduler->AddDynamicSchedule(pScheduleData) ){
		pScheduleData->Release();
		delete pScheduleData;
		return false;
	}
	
	return true;
}



char log_buffer[65535];

void AddStr(const char* pFormat,...)
{
	va_list args;
	char temp[1024];

	va_start(args, pFormat);
	vsprintf_safe(temp, pFormat, args);

	strcat_safe(log_buffer, temp);
	va_end(args);
}

void MBMatchServer::OnViewServerStatus()
{
	MGetServerStatusSingleton()->SaveToLogFile();
}

void MBMatchServer::InitLocator()
{
	if (!MGetServerConfig()->IsMasterServer())
		return;

	Locator = std::make_unique<MLocator>();
	if (!Locator->Create())
	{
		Log(LOG_ALL, "Failed to create locator");
		Locator.reset();
		return;
	}
	else
		Log(LOG_ALL, "Locator created!");
}

bool MBMatchServer::IsKeeper( const MUID& uidKeeper )
{
	MMatchObject* pObj = GetObject( uidKeeper );
	if( 0 == pObj )
		return false;

	if( !MGetServerConfig()->IsKeeperIP(pObj->GetIPString()) )
	{
		mlog( "Keeper hacking. " );
		if( 0 != pObj->GetIPString() )
			mlog( "IP:%s, ", pObj->GetIPString() );

		if( (0 != pObj->GetCharInfo()) && (0 != pObj->GetCharInfo()->m_szName) )
			mlog( "Name:%s", pObj->GetCharInfo()->m_szName );

		mlog( "\n" );

		return false;
	}

	return true;
}


void MBMatchServer::WriteServerInfoLog()
{
	mlog( "\n" );
	mlog( "================================== Server configure info ==================================\n" );

	char szTemp[256];
	sprintf_safe(szTemp, "Release Date : %s", __DATE__);
	Log(LOG_ALL, szTemp);
	
	if( MC_KOREA == MGetLocale()->GetCountry() )
		LOG( LOG_ALL, "Server Country : KOREA" );
	else if( MC_US == MGetLocale()->GetCountry() )
		LOG( LOG_ALL, "Server Country : US" );
	else if( MC_JAPAN == MGetLocale()->GetCountry() )
		LOG( LOG_ALL, "Server Country : JAPAN" );
	else if( MC_BRAZIL == MGetLocale()->GetCountry() )
		LOG( LOG_ALL, "Server Country : BRAZIL" );
	else if( MC_INDIA == MGetLocale()->GetCountry() )
		LOG( LOG_ALL, "Server Country : INDIA" );
	else
	{
		ASSERT( 0 && "국가 설정을 해주세요." );
		LOG( LOG_ALL, "!!!!!!!!!Not setted country code!!!!!!!!!!!!!" );
	}
	
	LOG( LOG_ALL, "Command version : (%u)", MCOMMAND_VERSION );
	LOG( LOG_ALL, "Event usable state : (%s)", MGetServerConfig()->IsUseEvent() ? "true" : "false" );
	LOG( LOG_ALL, "Load event size : (%u)", MMatchEventFactoryManager::GetInstance().GetLoadEventSize() );
	LOG( LOG_ALL, "FileCRCCheckSum usable state : (%s)", MGetServerConfig()->IsUseFileCrc() ? "true" : "false" );
	LOG( LOG_ALL, "FileCRC size : (%u)", MMatchAntiHack::GetFielCRCSize() );
	LOG( LOG_ALL, "Country Code Filter usalbe state : (%s)", MGetServerConfig()->IsUseFilter() ? "true" : "false" );
	LOG( LOG_ALL, "Accept Invalied IP state : (%s)", MGetServerConfig()->IsAcceptInvalidIP() ? "true" : "false" );
	LOG( LOG_ALL, "Keeper IP : (%s)", MGetServerConfig()->GetKeeperIP().c_str() );

	mlog( "===========================================================================================\n" );
	mlog( "\n" );
}

void MBMatchServer::OnRun()
{
	if (Locator)
		Locator->Run();

	MMatchServer::OnRun();
}

void MatchServerCustomLog(const char* Msg)
{
	MBMatchServerLog(MMatchServer::LOG_ALL & ~MMatchServer::LOG_FILE, Msg, false);
}

#ifdef USE_WEBSOCKET
// ---------------------------------------------------------------------------
// NetSend — transport dispatch: WebSocket handles go to WsListener, all
// others go to the base NetIO path (MServer::NetSend → Net.Send).
// ---------------------------------------------------------------------------
// WebSocket connection handles are raw heap pointers cast to uintptr_t and
// are always much larger than any TCP file descriptor (which is a small
// non-negative integer, typically < 1024 on a server).  This helper lets
// NetSend / NetDisconnect distinguish between a live-or-dead WS handle and a
// genuine TCP fd so they never accidentally pass a WS handle to NetIO.
static inline bool IsWebSocketHandle(uintptr_t handle)
{
    return handle > 65535;
}

bool MBMatchServer::NetSend(uintptr_t handle, void* data, int size)
{
    if (WsListener && WsListener->HasConnection(handle))
    {
        WsListener->Send(handle, data, size);
        free(data);
        return true;
    }
    // If the handle looks like a WebSocket handle (heap pointer) but is no
    // longer in the connection map (OnClose already fired), silently discard
    // the send instead of passing a dangling pointer to NetIO::Send, which
    // would call shared_from_this() on a destroyed connection and throw
    // std::bad_weak_ptr.
    if (WsListener && IsWebSocketHandle(handle))
    {
        free(data);
        return false;
    }
    return MMatchServer::NetSend(handle, data, size);
}

void MBMatchServer::NetDisconnect(uintptr_t handle)
{
    // For WebSocket connections, WsListener::Disconnect clears the context map
    // entry first (preventing stale GetContext returns) then closes the socket.
    // This ensures that if MC_NET_CLEAR frees the MCommObject while the WS
    // close handshake is still in flight, subsequent OnMessage/OnClose callbacks
    // will find a null context and safely ignore the freed object.
    if (WsListener && WsListener->HasConnection(handle))
    {
        WsListener->Disconnect(handle);
        return;
    }
    // Already-closed WS handle: nothing to do (connection is gone).
    if (WsListener && IsWebSocketHandle(handle))
        return;
    MMatchServer::NetDisconnect(handle);
}

// ---------------------------------------------------------------------------
// OnWsEvent — WebSocket event callback
// Mirrors MServer::RCPCallback but uses WsListener's per-connection context
// map instead of NetIO's, because WebSocket handles are not known to NetIO.
// ---------------------------------------------------------------------------
void MBMatchServer::OnWsEvent(WebSocketListener& WsListener,
                              NetIO::IOOperation Op,
                              WebSocketListener::ConnectionHandle Handle,
                              const void* Data)
{
	switch (Op)
	{
	case NetIO::IOOperation::Accept:
	{
		auto AData = static_cast<const NetIO::AcceptData*>(Data);
		MCommObject* pCommObj = new MCommObject(this);

		// Build IP string from the address in AcceptData.
		// AcceptData::Address is big-endian (host-byte-order u32 of IPv4).
		MSocket::in_addr addr;
		addr.s_addr = AData->Address;
		char IPString[64];
		GetIPv4String(addr, IPString);
		pCommObj->SetAddress(IPString, AData->Port);
		pCommObj->SetUserContext(Handle);

		OnAccept(pCommObj);

		WsListener.SetContext(Handle, pCommObj);
		break;
	}
	case NetIO::IOOperation::Disconnect:
	{
		auto pCommObj = static_cast<MCommObject*>(WsListener.GetContext(Handle));
		if (pCommObj)
			OnDisconnect(pCommObj->GetUID());
		break;
	}
	case NetIO::IOOperation::Read:
	{
		auto RData = static_cast<const NetIO::ReadData*>(Data);
		auto pPacket    = RData->Data.data();
		auto dwPacketLen = RData->Data.size();
		auto pCommObj   = static_cast<MCommObject*>(WsListener.GetContext(Handle));
		if (pCommObj && pCommObj->IsAllowed())
		{
			MCommandBuilder* pCmdBuilder = pCommObj->GetCommandBuilder();
			if (pCmdBuilder)
			{
				if (!pCmdBuilder->Read(reinterpret_cast<char*>(pPacket), dwPacketLen))
				{
					pCommObj->SetAllowed(false);
					WsListener.Disconnect(Handle);
					return;
				}

				while (MCommand* pCmd = pCmdBuilder->GetCommand())
					PostSafeQueue(pCmd);

				while (MPacketHeader* pNetCmd = pCmdBuilder->GetNetCommand())
				{
					if (pNetCmd->nMsg == MSGID_REPLYCONNECT)
					{
						auto* pMsg = reinterpret_cast<MReplyConnectMsg*>(pNetCmd);
						MUID HostUID, AllocUID;
						HostUID.High = pMsg->nHostHigh;
						HostUID.Low  = pMsg->nHostLow;
						AllocUID.High = pMsg->nAllocHigh;
						AllocUID.Low  = pMsg->nAllocLow;
						unsigned int nTimeStamp = pMsg->nTimeStamp;
						free(pNetCmd);

						LockCommList();
						OnConnected(&HostUID, &AllocUID, nTimeStamp, pCommObj);
						UnlockCommList();
					}
					else
					{
						free(pNetCmd);
					}
				}
			}
		}
		break;
	}
	default:
		break;
	}
}
#endif // USE_WEBSOCKET