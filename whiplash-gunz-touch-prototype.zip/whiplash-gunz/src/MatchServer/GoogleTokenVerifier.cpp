#include "stdafx.h"
#include "GoogleTokenVerifier.h"
#include <curl/curl.h>
#include <ctime>
#include <cstring>

// rapidjson headers
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"

static size_t WriteCallback(char* ptr, size_t size, size_t nmemb, void* userdata)
{
    auto* out = static_cast<std::string*>(userdata);
    out->append(ptr, size * nmemb);
    return size * nmemb;
}

bool VerifyGoogleIdToken(
    const std::string& idToken,
    const std::string& expectedAudience,
    GoogleTokenClaims& outClaims,
    std::string& outErrorMsg)
{
    CURL* curl = curl_easy_init();
    if (!curl)
    {
        outErrorMsg = "curl_easy_init failed";
        return false;
    }

    std::string url = "https://oauth2.googleapis.com/tokeninfo?id_token=";
    url += idToken;

    std::string responseBody;

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);       // required for multi-threaded use
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L); // cap DNS + TCP connect phase
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);       // total transfer timeout
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

    CURLcode res = curl_easy_perform(curl);

    long httpCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK)
    {
        outErrorMsg = std::string("curl error: ") + curl_easy_strerror(res);
        return false;
    }

    if (httpCode != 200)
    {
        outErrorMsg = "Google tokeninfo returned HTTP " + std::to_string(httpCode)
            + ": " + responseBody;
        return false;
    }

    // Parse JSON
    rapidjson::Document doc;
    doc.Parse(responseBody.c_str());

    if (doc.HasParseError())
    {
        outErrorMsg = std::string("JSON parse error: ")
            + rapidjson::GetParseError_En(doc.GetParseError());
        return false;
    }

    // Verify aud
    if (!doc.HasMember("aud") || !doc["aud"].IsString())
    {
        outErrorMsg = "Missing 'aud' field in tokeninfo response";
        return false;
    }
    std::string aud = doc["aud"].GetString();
    if (!expectedAudience.empty() && aud != expectedAudience)
    {
        outErrorMsg = "Token audience mismatch: got '" + aud
            + "', expected '" + expectedAudience + "'";
        return false;
    }

    // Verify exp
    if (!doc.HasMember("exp") || !doc["exp"].IsString())
    {
        outErrorMsg = "Missing 'exp' field in tokeninfo response";
        return false;
    }
    int64_t exp = static_cast<int64_t>(std::stoll(doc["exp"].GetString()));
    if (exp <= static_cast<int64_t>(time(nullptr)))
    {
        outErrorMsg = "Token has expired";
        return false;
    }

    // Extract claims
    if (!doc.HasMember("sub") || !doc["sub"].IsString())
    {
        outErrorMsg = "Missing 'sub' field in tokeninfo response";
        return false;
    }
    outClaims.sub = doc["sub"].GetString();
    outClaims.aud = aud;

    if (doc.HasMember("email") && doc["email"].IsString())
        outClaims.email = doc["email"].GetString();

    if (doc.HasMember("name") && doc["name"].IsString())
        outClaims.name = doc["name"].GetString();
    else if (doc.HasMember("given_name") && doc["given_name"].IsString())
        outClaims.name = doc["given_name"].GetString();

    return true;
}
