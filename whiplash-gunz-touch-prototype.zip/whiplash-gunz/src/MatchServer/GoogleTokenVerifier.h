#pragma once
#include <string>

struct GoogleTokenClaims {
    std::string sub;
    std::string email;
    std::string name;
    std::string aud;
};

// Verifies a Google ID token via the tokeninfo endpoint.
// Returns true and fills outClaims on success.
// Returns false and sets outErrorMsg on failure.
bool VerifyGoogleIdToken(
    const std::string& idToken,
    const std::string& expectedAudience,
    GoogleTokenClaims& outClaims,
    std::string& outErrorMsg);
