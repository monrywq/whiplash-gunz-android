# Contributing to Whiplash GunZ

Thanks for helping keep GunZ: The Duel alive in the browser! This document explains how to report issues, propose changes, and get a pull request merged.

## Ground rules

- Be respectful and constructive.
- All comments, log messages, and string literals in source code must be written in **English**.
- **Never post secrets** (`REGISTRATION_SECRET`, Admin API tokens, `server.ini` contents with credentials) in issues, PRs, or logs.
- Security vulnerabilities go through [SECURITY.md](SECURITY.md), **not** the public issue tracker.
- This project contains **no proprietary game assets** and PRs must not add any. Asset hosting is external and user-provided.

## Filing issues

Search existing issues first. A good bug report includes:

- **Mode** — serverless (`server_mode=worker`) or live multiplayer (`server_mode=websocket`), and whether the server is your own build.
- **Environment** — browser + version, OS, GPU if rendering-related; for server issues, the build type (native/Docker) and platform.
- **Reproduction** — exact steps, URL parameters, and the browser console / server log output (redact IPs and tokens).
- **Expected vs. actual behavior** — screenshots or short clips help a lot for rendering/input issues.

## Development setup

See the [README](README.md#building) for full build instructions (Emscripten SDK or Docker). Quick reference:

```bash
./build-wasm-client.sh             # WASM client (debug)
./build-matchserver-ws.sh          # native WebSocket MatchServer
./build-wasm-docker.sh             # same, zero-setup via Docker
```

## Pull requests

1. Fork and create a topic branch from `main`.
2. Keep PRs focused — one logical change per PR. Large refactors should be discussed in an issue first.
3. Use clear, imperative commit messages (`fix:`, `feat:`, `refactor:` prefixes preferred).
4. Verify before pushing:
   - The client builds (`./build-wasm-client.sh`) and boots to the main menu in a browser.
   - If you touched server code, the native MatchServer builds (`./build-matchserver-ws.sh`) and accepts a client connection.
5. Explain **why** in the PR description and link the related issue.

### Things to know before touching specific areas

- **Rendering / UI / input** — the renderer maps an internal **800×600** surface onto a **1024×768** canvas. Any UI or input work must account for this scaling.
- **Networking & crypto (`src/CSCommon/`)** — `MMakeSeedKey` (`MMatchUtil.cpp`), `MPacketCrypter`, the `MPacketHeader` layout, and the WebSocket framing (`0x01` TCP / `0x02` UDP prefixes) are **shared wire contracts**. They are independently re-implemented in TypeScript by [whiplash-gunz-api](https://github.com/LostMyCode/whiplash-gunz-api) for web-based account registration. Any change here requires a matching change there and a coordinated deployment — call this out prominently in your PR.
- **Admin HTTP API (`src/MatchServer/MMatchAdminHttp.cpp`)** — routes and JSON field names are consumed by the Discord bot in whiplash-gunz-api. Treat request/response schemas as public API: additive changes only, or coordinate both repos.
- **C++ conventions** — the codebase is legacy C++ modernized incrementally. Prefer RAII and bounds-checked helpers (`strcpy_safe`, `Split`, `StringView`) over raw C string handling in code you touch; don't reformat code you aren't changing.
- **WASM/JS shims (`src/wasm/`)** — keep the JS side framework-free; match the existing module pattern in `managers_post.js` / `js/features/`.

## License

By contributing, you agree that your contributions are licensed under the [MIT License](LICENSE). Please respect the licenses and attribution of the upstream GunZ source lineage credited in the README.
