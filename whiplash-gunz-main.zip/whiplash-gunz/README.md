<div align="center">

# Whiplash GunZ

**GunZ: The Duel — the classic third-person shooter — running entirely in the browser via WebAssembly.**

Play in-browser with a self-contained MatchServer compiled to WASM and running in a Web Worker, or connect directly to a native WebSocket game server for full multiplayer.

[![Play Now](https://img.shields.io/badge/▶_Play_Now-gunz.sigr.io-22c55e?style=for-the-badge)](https://gunz.sigr.io/)

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
![WebAssembly](https://img.shields.io/badge/WebAssembly-654FF0?logo=webassembly&logoColor=white)
![Built with Emscripten](https://img.shields.io/badge/built%20with-Emscripten-orange)
![Platform](https://img.shields.io/badge/platform-Browser%20%7C%20Linux-lightgrey)
[![Discord](https://img.shields.io/badge/Join-Discord-5865F2?logo=discord&logoColor=white)](https://discord.gg/ABG8JxuBQm)

</div>

<!-- TODO: add gameplay screenshots / GIF under docs/screenshots/ and embed here -->

---

## Features

- **Plays in any modern browser** — no install, no plugins. The original C++ client is compiled to WebAssembly with Emscripten.
- **Serverless mode** — the MatchServer itself is compiled to WASM and runs inside a Web Worker, so a full game session works with zero backend.
- **Live multiplayer mode** — connect directly to a native WebSocket-enabled MatchServer. No TCP/UDP proxy required.
- **D3D9 → WebGL renderer** — a custom Direct3D 9 compatibility layer translates the original rendering pipeline to WebGL.
- **Streamed assets** — game data is fetched on demand and cached via the browser Cache API; no multi-gigabyte upfront download.
- **Google sign-in** — optional OAuth login backed by the MatchServer.
- **Optimized release pipeline** — Closure Compiler minification and content-hashed filenames for cache busting, built in.

## Architecture

Whiplash GunZ is the original GunZ codebase with three compatibility layers replacing its native dependencies, plus a MatchServer that can run either in the browser or as a native binary.

```mermaid
flowchart TB
    subgraph Browser["🌐 Browser"]
        Client["GunzWasm (WASM)<br/>game client"]
        D3D9["wasm-d3d9-wrapper<br/>D3D9 → WebGL"]
        Net["WebSocketNetManager<br/>TCP/UDP shim"]
        Client --- D3D9
        Client --- Net

        subgraph WorkerMode["server_mode=worker (default)"]
            Worker["MatchServerWorker.js"]
            MWasm["MatchServer (WASM)<br/>in-browser server"]
            Worker --- MWasm
        end
        Net -- "postMessage" --> Worker
    end

    Net -. "server_mode=websocket<br/>direct WebSocket" .-> Native["Native MatchServer<br/>(websocketpp + Asio)"]
```

| Layer       | Native original   | Browser replacement                                          |
| ----------- | ----------------- | ------------------------------------------------------------ |
| Rendering   | Direct3D 9        | WebGL via `src/wasm/wasm-d3d9-wrapper/`                      |
| Networking  | TCP / UDP sockets | WebSocket shim (`WebSocketNetManager` in `managers_post.js`) |
| File system | Local disk        | Emscripten VFS (MEMFS) with streamed, cached assets          |

## Quick Start

The fastest way to play is the hosted build: **[gunz.sigr.io](https://gunz.sigr.io/)**.

It loads in serverless mode by default — the MatchServer boots inside a Web Worker and no backend is involved. To connect to a live multiplayer server instead:

```
https://gunz.sigr.io/?server_mode=websocket&ws_server=ws://YOUR_SERVER:6032
```

## Building

Install the prerequisites below and build directly, or use [Docker](#docker-builds) for a zero-setup, reproducible environment.

### Prerequisites

- [Emscripten SDK](https://emscripten.org/docs/getting_started/downloads.html) (`emcc` on your `PATH`)
- CMake 3.x and Ninja
- Python 3 (used for cache-busting output filenames)

```bash
git clone https://github.com/emscripten-core/emsdk.git ~/emsdk
~/emsdk/emsdk install latest && ~/emsdk/emsdk activate latest
source ~/emsdk/emsdk_env.sh
```

### Build the WASM client

```bash
./build-wasm-client.sh           # debug   → build/GunzWasm.html
./build-wasm-client.sh release   # release → build-release/GunzWasm.html
```

Open the resulting `GunzWasm.html` from any static web server. Game assets are streamed from a remote asset host ([gunz.sigr.io/game-data](https://gunz.sigr.io/game-data/)) and cached on first load.

### Build the native WebSocket MatchServer (optional)

Only needed for hosting live multiplayer. The server speaks WebSocket directly via `websocketpp` + Asio — no separate proxy.

```bash
./build-matchserver-ws.sh          # release (default)
./build-matchserver-ws.sh debug    # debug
# → build-matchserver-release/bin/MatchServer
```

### Docker builds

Build either target in a container with only Docker installed — none of the prerequisites above are needed. Output lands in separate `build-docker*` directories, so it never clashes with a native build.

```bash
# WASM client
./build-wasm-docker.sh           # debug   → build-docker/GunzWasm.html
./build-wasm-docker.sh release   # release → build-docker-release/GunzWasm.html

# Native MatchServer
./build-matchserver-docker.sh          # release (default)
./build-matchserver-docker.sh debug    # debug
./build-matchserver-docker.sh clean    # remove Docker build dirs
# → build-matchserver-docker-release/bin/MatchServer
```

The first run pulls the build images (~3 GB for the WASM client, ~600 MB for the server) and compiles cold; after that a persistent ccache keeps incremental rebuilds quick — roughly 60s for the client and 10s for the server.

## Project Structure

```
src/wasm/                      WASM entry point, JS shell, and compatibility shims
  WasmMain.cpp                 Boot sequence: VFS sync → engine init
  wasm-d3d9-wrapper/           Direct3D 9 → WebGL translation layer
  managers_post.js             WebSocketNetManager + audio/overlay managers
  MatchServerWorker.js         Web Worker host for the in-browser MatchServer
  gunz_shell.html              HTML shell: asset streaming, launch config
src/CSCommon/                  Shared networking & crypto (NetIO, MPacketCrypter, WebSocketListener)
src/MatchServer/               MatchServer logic (Google OAuth, admin HTTP, game rules)
src/matchserver-ws/            MatchServer WebSocket build configuration
src/Gunz, RealSpace2, ...      Original GunZ client modules
build-wasm-client.sh           Build the browser client
build-matchserver-ws.sh        Build the native WebSocket MatchServer
```

## Network Modes

Selected at launch via URL query parameters.

| Parameter                                         | Server                             | Use case                                  |
| ------------------------------------------------- | ---------------------------------- | ----------------------------------------- |
| `?server_mode=worker` _(default)_                 | `MatchServer.wasm` in a Web Worker | Offline / demo, no backend needed         |
| `?server_mode=websocket&ws_server=ws://HOST:PORT` | Native WebSocket MatchServer       | Live multiplayer with persistent accounts |

In WebSocket mode the client tunnels socket traffic over a single binary WebSocket connection. The server's `WebSocketListener` decodes the framing directly:

- `0x01 + payload` → TCP stream data
- `0x02 + IP(4) + Port(2, LE) + payload` → UDP datagram

## Related Repositories

- **[whiplash-gunz-api](https://github.com/LostMyCode/whiplash-gunz-api)** — AWS Lambda stack for web account registration (speaks the MCommand protocol over WebSocket to the MatchServer) and Discord slash commands (via the Admin HTTP API). The packet key schedule, cipher, and Admin API schemas are shared contracts between the two repositories; cross-cutting changes must land in both.

## Community & Support

- **Discord** — [discord.gg/ABG8JxuBQm](https://discord.gg/ABG8JxuBQm) — questions, feedback, and multiplayer coordination
- **X / Twitter** — [@LostMyCode](https://x.com/LostMyCode) — announcements and updates
- **GitHub Issues** — [whiplash-gunz/issues](https://github.com/LostMyCode/whiplash-gunz/issues) — bug reports and feature requests

## Contributing

Issues and pull requests are welcome — see [CONTRIBUTING.md](CONTRIBUTING.md) for the full guide, and [SECURITY.md](SECURITY.md) for reporting vulnerabilities privately. Two conventions to keep in mind:

- All comments, log messages, and string literals in source code must be written in **English**.
- The renderer maps an internal **800×600** surface onto a **1024×768** canvas; keep this scaling in mind for any UI or input work.

## License

Released under the [MIT License](LICENSE).

Whiplash GunZ builds on the GunZ source lineage — please respect the licenses and attribution of the upstream projects credited below.

## Credits

- **[LostMyCode](https://github.com/LostMyCode)** — WebAssembly port (client + in-browser MatchServer)
- **[Crawly / Asunaya](https://github.com/Asunaya)** — [Refined GunZ](https://github.com/Asunaya/RefinedGunz)
- **[SuhBruh](https://github.com/suhbruh)**, **[Michael Steshenko](https://github.com/Michael-Steshenko)**, ThievingSix — [International GunZ](https://igunz.net) / Open GunZ

## Disclaimer

This is a fan-made, community preservation project. It is **not affiliated with, endorsed by, or sponsored by MAIET Entertainment** or any other rights holder of the original GunZ: The Duel. "GunZ" and related trademarks belong to their respective owners.

This repository contains **no proprietary game assets** — no models, textures, sounds, maps, or other game data from the original commercial release. It is source code only; asset hosting for the live deployment at gunz.sigr.io is external and provided independently of this repository.
