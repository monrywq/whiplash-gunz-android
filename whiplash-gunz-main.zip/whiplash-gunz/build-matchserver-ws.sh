#!/bin/bash
# Build script for MatchServer with WebSocket support
# Usage:
#   ./build-matchserver-ws.sh           # release build (default)
#   ./build-matchserver-ws.sh debug     # debug build
#   ./build-matchserver-ws.sh release   # release build
#   ./build-matchserver-ws.sh clean     # remove build directories
#
# Output:
#   The built binary is left in the build directory by default.
#   Set MATCHSERVER_OUTPUT_DIR to copy the binary to a specific directory.
#   Set MATCHSERVER_OUTPUT_NAME to override the output filename
#   (defaults to MatchServer-ws on arm64, MatchServer-ws-x64 on x86_64).

set -eo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVER_WASM_DIR="$SCRIPT_DIR/src/matchserver-ws"

MODE="${1:-release}"

case "$MODE" in
  clean)
    echo "Removing build directories..."
    rm -rf "$SCRIPT_DIR/build-matchserver" "$SCRIPT_DIR/build-matchserver-release" \
           "$SCRIPT_DIR/build-matchserver-docker" "$SCRIPT_DIR/build-matchserver-docker-release"
    echo "Done."
    exit 0
    ;;
  debug)
    BUILD_DIR="$SCRIPT_DIR/build-matchserver"
    CMAKE_BUILD_TYPE="Debug"
    ;;
  release)
    BUILD_DIR="$SCRIPT_DIR/build-matchserver-release"
    CMAKE_BUILD_TYPE="Release"
    ;;
  *)
    echo "Usage: $0 [debug|release|clean]"
    exit 1
    ;;
esac

# Docker builds use isolated dirs to avoid CMakeCache path conflicts with native builds
if [ -n "${DOCKER_BUILD:-}" ]; then
    case "$MODE" in
        debug)   BUILD_DIR="$SCRIPT_DIR/build-matchserver-docker" ;;
        release) BUILD_DIR="$SCRIPT_DIR/build-matchserver-docker-release" ;;
    esac
fi

NPROC=$(nproc 2>/dev/null || sysctl -n hw.logicalcpu 2>/dev/null || echo 4)
OUTPUT_DIR="${MATCHSERVER_OUTPUT_DIR:-}"
HOST_ARCH="$(uname -m)"
case "${MATCHSERVER_OUTPUT_NAME:-}" in
  "")
    case "$HOST_ARCH" in
      aarch64|arm64) OUTPUT_NAME="MatchServer-ws" ;;
      x86_64) OUTPUT_NAME="MatchServer-ws-x64" ;;
      *) OUTPUT_NAME="MatchServer-ws-${HOST_ARCH}" ;;
    esac
    ;;
  *)
    OUTPUT_NAME="$MATCHSERVER_OUTPUT_NAME"
    ;;
esac

echo "=== MatchServer WebSocket build ==="
echo "  Mode      : $MODE ($CMAKE_BUILD_TYPE)"
echo "  Build dir : $BUILD_DIR"
echo "  Jobs      : $NPROC"
if [ -n "$OUTPUT_DIR" ]; then
  echo "  Output    : ${OUTPUT_DIR}/${OUTPUT_NAME}"
else
  echo "  Output    : (build dir only)"
fi
echo

mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

cmake \
  -DUSE_WEBSOCKET=ON \
  -DCMAKE_BUILD_TYPE="$CMAKE_BUILD_TYPE" \
  "$SERVER_WASM_DIR"

cmake --build . --target MatchServer -- -j"$NPROC"

BIN="$BUILD_DIR/bin/MatchServer"
echo
echo "=== Build complete ==="
echo "  Binary: $BIN"
echo "  Size  : $(du -sh "$BIN" | cut -f1)"

if [ -n "$OUTPUT_DIR" ]; then
  mkdir -p "$OUTPUT_DIR"
  install -m 755 "$BIN" "$OUTPUT_DIR/$OUTPUT_NAME"
  echo "  Copied  : $OUTPUT_DIR/$OUTPUT_NAME"
fi
