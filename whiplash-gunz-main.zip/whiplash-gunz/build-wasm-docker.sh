#!/bin/bash
set -eo pipefail

IMAGE="gunz-wasm-client:6.0.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

BUILD_TYPE="${1:-debug}"

# Build image only if it doesn't already exist
if ! docker image inspect "$IMAGE" > /dev/null 2>&1; then
    echo "Image $IMAGE not found. Building..."
    docker build -f "$SCRIPT_DIR/Dockerfile.wasm-client" -t "$IMAGE" "$SCRIPT_DIR"
fi

# Pre-create output dirs and ccache dir to avoid permission issues
mkdir -p "$SCRIPT_DIR/build-docker"
mkdir -p "$SCRIPT_DIR/build-docker-release"
mkdir -p "$HOME/.ccache-docker"

docker run --rm \
    -v "$SCRIPT_DIR:/src" \
    -v "$HOME/.ccache-docker:/ccache" \
    -u "$(id -u):$(id -g)" \
    -e HOME=/tmp \
    -e DOCKER_BUILD=1 \
    -e EXTRA_CMAKE_ARGS="-DCMAKE_CXX_COMPILER_LAUNCHER=ccache -DCMAKE_C_COMPILER_LAUNCHER=ccache" \
    "$IMAGE" \
    /src/build-wasm-client.sh "$BUILD_TYPE"
