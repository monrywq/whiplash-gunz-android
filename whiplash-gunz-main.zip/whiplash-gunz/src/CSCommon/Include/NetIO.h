#pragma once
#include "GlobalTypes.h"
#include "optional.h"
#include "function_view.h"
#include <functional>


#ifdef __EMSCRIPTEN__
#define USE_WASM_NET 1
#endif

#if !defined(_WIN32) && !defined(USE_WASM_NET)
#define USE_ASIO 1
#endif

#ifdef USE_ASIO
#include <thread>
#include <array>
#define ASIO_STANDALONE
#include "asio.hpp"
#ifdef R_OK
#undef R_OK
#endif
namespace asio {
using io_context = io_service;
}
#elif !defined(USE_WASM_NET)
#include "RealCPNet.h"
#endif

#include <vector>
#include <memory>
#include "MInetUtil.h"

struct NetIO
{
	struct Connection
#ifdef USE_ASIO
		: std::enable_shared_from_this<Connection>
#endif
	{
#if !defined(USE_ASIO) && !defined(USE_WASM_NET)
		SOCKET Socket;
#elif defined(USE_ASIO)
		Connection(asio::io_context& IOContext, asio::ip::tcp::socket Socket, void* Context = nullptr)
			: Socket(std::move(Socket)), Strand(IOContext), Context(Context) {}
		asio::ip::tcp::socket Socket;
		asio::io_context::strand Strand;
		void* Context;
		std::array<u8, 8192> ReadBuffer;
#else // USE_WASM_NET
		Connection(int Handle, void* Context = nullptr)
			: Handle(Handle), Context(Context) {}
		int Handle;
		void* Context;
#endif
	};

#if !defined(USE_ASIO) && !defined(USE_WASM_NET)
	using ConnectionHandle = SOCKET;
#else
	using ConnectionHandle = uintptr_t;
	static constexpr ConnectionHandle InvalidHandle = 0;
#endif

	enum class IOOperation
	{
		None,
		Accept,
		Connect,
		Disconnect,
		Read,
		Write,
	};

	struct AcceptData
	{
		u32 Address;
		u16 Port;
	};

	struct ReadData
	{
		ArrayView<u8> Data;
	};

	using CallbackType = std::function<void(IOOperation, ConnectionHandle, const void*)>;
	using LogCallbackType = void(const char*, ...);

	bool Create(int Port, CallbackType Callback, bool Reuse = false);
	void Destroy();

	void Update();

	ConnectionHandle Connect(u32 Address, int Port, void* Context);
	ConnectionHandle Connect(const char* szAddress, int Port, void* Context);
	void Disconnect(ConnectionHandle Handle);

	bool Send(ConnectionHandle Handle, void* Packet, int Size);

	void* GetContext(ConnectionHandle Handle);
	void SetContext(ConnectionHandle Handle, void* Context);

	void Dispatch(IOOperation Op, ConnectionHandle Handle, const void* Data) {
		Callback(Op, Handle, Data);
	}

	void SetLogCallback(LogCallbackType Callback);
	void SetLogLevel(int Level);

private:
	CallbackType Callback;
#if !defined(USE_ASIO) && !defined(USE_WASM_NET)
	MRealCPNet RealCPNet;
#elif defined(USE_ASIO)
	void Accept();
	void Read(std::shared_ptr<Connection> Conn);
	
	asio::io_context IOContext;
	asio::ip::tcp::socket ListenSocket{IOContext};
	asio::ip::tcp::acceptor Acceptor{IOContext};
	asio::ip::tcp::socket AcceptSocket{IOContext};
	std::vector<std::shared_ptr<Connection>> Connections;
	std::mutex ConnectionsMutex;
	std::atomic<bool> Stopped{false};

	template <typename... Args>
	void Log(Args... args)
	{
		if (LogLevel)
			LogCallback(args...);
	}

	LogCallbackType LogCallback;
	int LogLevel = 0;
#else // USE_WASM_NET
	std::vector<std::shared_ptr<Connection>> Connections;
#endif
};
