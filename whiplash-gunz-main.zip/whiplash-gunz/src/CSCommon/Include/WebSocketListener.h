#pragma once
#ifdef USE_WEBSOCKET

// websocketpp requires _WIN32_WINNT >= 0x0600, so define it before
// targetver.h (which sets 0x0501) is pulled in transitively.
#ifdef _WIN32
#  ifndef _WIN32_WINNT
#    define _WIN32_WINNT 0x0600
#  elif _WIN32_WINNT < 0x0600
#    undef  _WIN32_WINNT
#    define _WIN32_WINNT 0x0600
#  endif
#endif

#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>

#define ASIO_STANDALONE
#define ASIO_HAS_STD_CHRONO
#include <websocketpp/config/asio_no_tls.hpp>
#include <websocketpp/server.hpp>

// Pull in NetIO definitions (IOOperation / AcceptData / ReadData / CallbackType)
#include "NetIO.h"

using WsServer = websocketpp::server<websocketpp::config::asio>;
using WsConnectionHdl = websocketpp::connection_hdl;

class WebSocketListener
{
public:
    // Reuse NetIO's ConnectionHandle type (uintptr_t on Linux/USE_ASIO)
    using ConnectionHandle = uintptr_t;

    // TCP event callback: same semantics as NetIO::CallbackType but uses
    // std::function so it can capture state (unlike function_view).
    using CallbackType = std::function<void(NetIO::IOOperation,
                                            ConnectionHandle,
                                            const void*)>;

    // UDP callback: called when a 0x02 WebSocket frame is received.
    // Parameters: (handle, srcIp, srcPort [network-byte-order port as u16], packet, size)
    // handle  — the WebSocket connection that sent the frame; pass to SendUDP() to
    //           route the response back over the same WebSocket connection.
    // srcIp   — the peer IP of the WebSocket connection (NOT the IP embedded in the
    //           0x02 frame header, which is the *destination* IP from the client's view).
    // srcPort — a synthetic per-connection port derived from the connection handle so
    //           the locator can key on (ip, port) uniquely even if two clients share
    //           the same peer IP.
    // The packet contains the raw UDP payload bytes (without the 0x02 type byte and
    // the 6-byte IP+port prefix embedded by the client).
    using UdpCallbackType = std::function<void(ConnectionHandle handle,
                                               uint32_t srcIp,
                                               uint16_t srcPort,
                                               const char* packet,
                                               uint32_t size)>;

    // port:        WebSocket listen port (typically 6032)
    // callback:    Accept / Read / Disconnect event callback (TCP frames)
    // udpCallback: handler for incoming 0x02 UDP frames (may be nullptr)
    // udpPort:     UDP port reported back in 0x02 responses (informational, default 8900)
    bool Start(uint16_t port,
               CallbackType callback,
               UdpCallbackType udpCallback = nullptr,
               uint16_t udpPort = 8900);
    void Stop();

    // Send a TCP response to a WebSocket client: [0x01] + payload
    void Send(ConnectionHandle handle, const void* data, size_t len);

    // Send a UDP response to a WebSocket client: [0x02] + IP(4) + Port(2 LE) + payload
    void SendUDP(ConnectionHandle handle,
                 uint32_t srcIp, uint16_t srcPort,
                 const void* data, size_t len);

    // Context store — mirrors NetIO::SetContext/GetContext for WS connections
    void  SetContext(ConnectionHandle handle, void* context);
    void* GetContext(ConnectionHandle handle) const;

    // Disconnect a WebSocket connection by handle
    void Disconnect(ConnectionHandle handle);

    // Returns true if handle belongs to an active WebSocket connection.
    // Used by MBMatchServer to route sends to the correct transport.
    bool HasConnection(ConnectionHandle handle) const;

private:
    void OnOpen(WsConnectionHdl hdl);
    void OnMessage(WsConnectionHdl hdl, WsServer::message_ptr msg);
    void OnClose(WsConnectionHdl hdl);

    WsServer        m_server;
    CallbackType    m_callback;
    UdpCallbackType m_udpCallback;
    uint16_t        m_udpPort{8900};

    mutable std::mutex m_connMutex;
    // ConnectionHandle (raw connection pointer as uintptr_t) -> weak hdl
    std::unordered_map<ConnectionHandle, WsConnectionHdl> m_connections;
    // Per-connection user context (mirrors NetIO context map)
    std::unordered_map<ConnectionHandle, void*> m_contexts;

    std::thread m_thread;
};

#endif // USE_WEBSOCKET
