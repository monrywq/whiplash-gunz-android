#pragma once

#include "MUID.h"

#include <vector>
#include <list>
#include <set>
#include <deque>

#include "MCommandParameter.h"
#include "MCommandManager.h"
#include "MemPool.h"
#include "GlobalTypes.h"

// Command Description Flag
#define MCDT_NOTINITIALIZED		0
#define MCDT_MACHINE2MACHINE	1
#define MCDT_LOCAL				2
#define MCDT_TICKSYNC			4
#define MCDT_TICKASYNC			8
#define MCDT_USER				16
#define MCDT_ADMIN				32
#define MCDT_PEER2PEER			64

#define MCCT_NON_ENCRYPTED		128
#define MCCT_HSHIELD_ENCRYPTED	256

#define MAX_COMMAND_PARAMS		255

class MCommandDesc{
protected:
	int			m_nID;
	char		m_szName[256];
	char		m_szDescription[256];
	int			m_nFlag;

	std::vector<MCommandParameterDesc*>	m_ParamDescs;
public:
	MCommandDesc(int nID, const char* szName, const char* szDescription, int nFlag);
	virtual ~MCommandDesc();

	void AddParamDesc(MCommandParameterDesc* pParamDesc);

	bool IsFlag(int nFlag) const;
	int GetID() const { return m_nID; }
	const char* GetName(void) const { return m_szName; }
	const char* GetDescription(void) const { return m_szDescription; }
	MCommandParameterDesc* GetParameterDesc(int i) const {
		if(i<0 || i>=(int)m_ParamDescs.size()) return NULL;
		return m_ParamDescs[i];
	}
	int GetParameterDescCount(void) const {
		return (int)m_ParamDescs.size();
	}
	MCommandParameterType GetParameterType(int i) const
	{
		if(i<0 || i>=(int)m_ParamDescs.size()) return MPT_END;
		return m_ParamDescs[i]->GetType();
	}
	MCommandDesc* Clone();
};

class MCommand : public CMemPool<MCommand> 
{
public:
	MUID						m_Sender;
	MUID						m_Receiver;
	const MCommandDesc*			m_pCommandDesc;
	std::vector<MCommandParameter*>	m_Params;
	unsigned char				m_nSerialNumber;
	void ClearParam(int i);
	void Reset();

protected:
	void ClearParam();

public:
	MCommand();
	MCommand(const MCommandDesc* pCommandDesc, MUID Receiver, MUID Sender);
	MCommand(int nID, MUID Sender, MUID Receiver, MCommandManager* pCommandManager);
	virtual ~MCommand(void);

	void SetID(const MCommandDesc* pCommandDesc);
	void SetID(int nID, MCommandManager* pCommandManager);
	int GetID() const { return m_pCommandDesc->GetID(); }
	const char* GetDescription(){ return m_pCommandDesc->GetDescription(); }

	bool AddParameter(MCommandParameter* pParam);
	int GetParameterCount(void) const;
	MCommandParameter* GetParameter(int i) const;

	bool GetParameter(void* pValue, int i, MCommandParameterType t, int nBufferSize=-1) const;

	MUID GetSenderUID(void){ return m_Sender; }
	void SetSenderUID(const MUID &uid) { m_Sender = uid; }
	MUID GetReceiverUID(void){ return m_Receiver; }

	bool IsLocalCommand(void){ return (m_Sender==m_Receiver); }

	MCommand* Clone(void) const;

	bool CheckRule();	

	int GetData(char* pData, int nSize) const;
	template <typename T = std::allocator<u8>>
	bool SetData(const char* pData, MCommandManager* pCM, unsigned short nDataLen,
		bool ReadSerial, T& Alloc);
	bool SetData(const char* pData, MCommandManager* pCM,
		unsigned short nDataLen = USHRT_MAX, bool ReadSerial = true)
	{
		std::allocator<u8> alloc;
		return SetData(pData, pCM, nDataLen, true, alloc);
	}

	int GetSize() const;
};

template <typename T>
bool MCommand::SetData(const char* pData, MCommandManager* pCM, unsigned short nDataLen,
	bool ReadSerial, T& Alloc)
{
	Reset();

	unsigned short int nDataCount = 0;

	// Get Total Size
	unsigned short nTotalSize = 0;
	memcpy(&nTotalSize, pData, sizeof(nTotalSize));

	if ((nDataLen != USHRT_MAX) && (nDataLen != nTotalSize)) {
		printf("LOG: MCommand::SetData Size Mismatch! %d != %d\n", nDataLen, nTotalSize);
		return false;
	}

	nDataCount += sizeof(nTotalSize);

	// Command
	unsigned short int nCommandID = 0;
	memcpy(&nCommandID, pData + nDataCount, sizeof(nCommandID));
	nDataCount += sizeof(nCommandID);

	MCommandDesc* pDesc = pCM->GetCommandDescByID(nCommandID);
	if (pDesc == NULL)
	{
		printf("LOG: MCommand::SetData Unknown Command ID: %u (0x%X)\n", nCommandID, nCommandID);
		return false;
	}
	SetID(pDesc);

	if (ReadSerial)
	{
		memcpy(&m_nSerialNumber, pData + nDataCount, sizeof(m_nSerialNumber));
		// printf("LOG: MCommand::SetData SerialNumber=%u\n", (unsigned int)m_nSerialNumber);
		nDataCount += sizeof(m_nSerialNumber);
	}


	// Parameters
	int nParamCount = pDesc->GetParameterDescCount();

	for (int i = 0; i<nParamCount; ++i) {
		MCommandParameterType nParamType = pDesc->GetParameterType(i);

		// Print raw data at this offset for debugging
		const unsigned char* pRaw = (const unsigned char*)(pData + nDataCount);
		// Bounds check for debug print
		// if (nDataCount + 4 <= nDataLen) // Use nDataLen for safety if available, or just check standard sanity
		// {
		// 	printf("LOG: MCommand::SetData Param[%d] type=%d at offset %u: [%02X %02X %02X %02X]\n", 
		// 		i, nParamType, nDataCount, pRaw[0], pRaw[1], pRaw[2], pRaw[3]);
		// }
		// else
		// {
		// 	printf("LOG: MCommand::SetData Param[%d] type=%d at offset %u: [EOF]\n", i, nParamType, nDataCount);
		// }

		// EOF Check: If we ran out of data but still have parameters to parse
		if (nDataCount >= nTotalSize)
		{
			printf("LOG: MCommand::SetData Param[%d] Hit EOF! Creating default for type %d.\n", i, nParamType);
			
			MCommandParameter* pDefaultParam = NULL;
			switch(nParamType) {
				case MPT_INT: pDefaultParam = new MCommandParameterInt(0); break;
				case MPT_UINT: pDefaultParam = new MCommandParameterUInt(0); break;
				case MPT_FLOAT: pDefaultParam = new MCommandParameterFloat(0.0f); break;
				case MPT_STR: pDefaultParam = new MCommandParameterString(""); break;
				case MPT_VECTOR: pDefaultParam = new MCommandParameterVector(0.0f, 0.0f, 0.0f); break;
				case MPT_POS: pDefaultParam = new MCommandParameterPos(0.0f, 0.0f, 0.0f); break;
				case MPT_DIR: pDefaultParam = new MCommandParameterDir(0.0f, 0.0f, 0.0f); break;
				case MPT_BOOL: pDefaultParam = new MCommandParameterBool(false); break;
				case MPT_COLOR: pDefaultParam = new MCommandParameterColor(0, 0, 0); break;
				case MPT_UID: pDefaultParam = new MCommandParameterUID(MUID(0,0)); break;
				case MPT_BLOB: pDefaultParam = new MCommandParameterBlob(); break; 
				case MPT_CHAR: pDefaultParam = new MCommandParameterChar(0); break;
				case MPT_UCHAR: pDefaultParam = new MCommandParameterUChar(0); break;
				case MPT_SHORT: pDefaultParam = new MCommandParameterShort(0); break;
				case MPT_USHORT: pDefaultParam = new MCommandParameterUShort(0); break;
				case MPT_INT64: pDefaultParam = new MCommandParameterInt64(0); break;
				case MPT_UINT64: pDefaultParam = new MCommandParameterUInt64(0); break;
				case MPT_SVECTOR: pDefaultParam = new MCommandParameterShortVector((short)0, (short)0, (short)0); break;
				default: pDefaultParam = new MCommandParameterInt(0); break; // Fallback
			}
			m_Params.push_back(pDefaultParam);
			continue; // Skip the rest of the loop for this param
		}

		MCommandParameter* pParam = NULL;
		switch (nParamType) {
		case MPT_INT:
			pParam = new MCommandParameterInt;
			break;
		case MPT_UINT:
			pParam = new MCommandParameterUInt;
			break;
		case MPT_FLOAT:
			pParam = new MCommandParameterFloat;
			break;
		case MPT_STR:
			{
				unsigned short checkSize = 0;
				if (sizeof(checkSize) > (nTotalSize - nDataCount))
				{
					return false;
				}
				memcpy(&checkSize, pData + nDataCount, sizeof(checkSize));
				
				// Truncation Logic for malformed server packets
				if (checkSize > (nTotalSize - nDataCount))
				{
					
					// Calculate what's actually available (minus 2 bytes size header)
					int available = (nTotalSize - nDataCount) - sizeof(checkSize);
					if (available < 0) available = 0;
					
					// Create a string parameter with truncated content
					char* pTruncated = new char[available + 1];
					if (available > 0)
						memcpy(pTruncated, pData + nDataCount + sizeof(checkSize), available);
					pTruncated[available] = '\0';
					
					pParam = new MCommandParameterString(pTruncated);
					delete[] pTruncated;
					
					// Advance by the *available* amount (or the parsed amount if we want to be consistent with "read what we could")
					// But SetData loop adds nRead. We need to manually handle this.
					nDataCount += (sizeof(checkSize) + available);
					m_Params.push_back(pParam);
					continue; // Skip the standard SetData call
				}
			}
			pParam = new MCommandParameterString;
			break;
		case MPT_VECTOR:
			pParam = new MCommandParameterVector;
			break;
		case MPT_POS:
			pParam = new MCommandParameterPos;
			break;
		case MPT_DIR:
			pParam = new MCommandParameterDir;
			break;
		case MPT_BOOL:
			pParam = new MCommandParameterBool;
			break;
		case MPT_COLOR:
			pParam = new MCommandParameterColor;
			break;
		case MPT_UID:
			pParam = new MCommandParameterUID;
			break;
		case MPT_BLOB:
			{
				unsigned int checkSize = 0;
				memcpy(&checkSize, pData + nDataCount, sizeof(checkSize));
				if (checkSize > nTotalSize || checkSize == 0)
				{
					printf("LOG: MCommand::SetData Param[%d] BLOB size error: %u\n", i, checkSize);
					return false;
				}
			}
			pParam = new MCommandParameterBlob;
			break;
		case MPT_CHAR:
			pParam = new MCommandParameterChar;
			break;
		case MPT_UCHAR:
			pParam = new MCommandParameterUChar;
			break;
		case MPT_SHORT:
			pParam = new MCommandParameterShort;
			break;
		case MPT_USHORT:
			pParam = new MCommandParameterUShort;
			break;
		case MPT_INT64:
			pParam = new MCommandParameterInt64;
			break;
		case MPT_UINT64:
			pParam = new MCommandParameterUInt64;
			break;
		case MPT_SVECTOR:
			pParam = new MCommandParameterShortVector;
			break;
		default:
			_ASSERT(false);		// Unknow Parameter!!!
			return false;
		}

		int nRead = pParam->SetData(pData + nDataCount);
		// printf("LOG: MCommand::SetData Param[%d] type=%d read=%d\n", i, nParamType, nRead);
		nDataCount += nRead;

		m_Params.push_back(pParam);

		if (nDataCount > nTotalSize)
		{
			printf("LOG: MCommand::SetData Overflow after param %d! count=%u total=%u\n", i, nDataCount, nTotalSize);
			return false;
		}
	}

	if (nDataCount != nTotalSize)
	{
		printf("LOG: MCommand::SetData Exact size mismatch! count=%u total=%u\n", nDataCount, nTotalSize);
		// return false; // Sometimes original client allows this? But let's keep it for now.
	}

	// printf("LOG: MCommand::SetData Success! Command=%s nParams=%zu\n", pDesc->GetName(), m_Params.size());

	return true;
}


class MCommandSNChecker
{
private:
	int				m_nCapacity;
	std::deque<int>		m_SNQueue;
	std::set<int>		m_SNSet;
public:
	MCommandSNChecker();
	~MCommandSNChecker();
	void InitCapacity(int nCapacity);
	bool CheckValidate(int nSerialNumber);
};

#define NEWCMD(_ID)		(new MCommand(_ID))
#define MKCMD(_C, _ID)									{ _C = NEWCMD(_ID); }
#define MKCMD1(_C, _ID, _P0)							{ _C = NEWCMD(_ID); _C->AddParameter(new _P0); }
#define MKCMD2(_C, _ID, _P0, _P1)						{ _C = NEWCMD(_ID); _C->AddParameter(new _P0); _C->AddParameter(new _P1); }
#define MKCMD3(_C, _ID, _P0, _P1, _P2)					{ _C = NEWCMD(_ID); _C->AddParameter(new _P0); _C->AddParameter(new _P1); _C->AddParameter(new _P2); }
#define MKCMD4(_C, _ID, _P0, _P1, _P2, _P3)				{ _C = NEWCMD(_ID); _C->AddParameter(new _P0); _C->AddParameter(new _P1); _C->AddParameter(new _P2); _C->AddParameter(new _P3); }
#define MKCMD5(_C, _ID, _P0, _P1, _P2, _P3, _P4)		{ _C = NEWCMD(_ID); _C->AddParameter(new _P0); _C->AddParameter(new _P1); _C->AddParameter(new _P2); _C->AddParameter(new _P3); _C->AddParameter(new _P4); }
#define MKCMD6(_C, _ID, _P0, _P1, _P2, _P3, _P4, _P5)	{ _C = NEWCMD(_ID); _C->AddParameter(new _P0); _C->AddParameter(new _P1); _C->AddParameter(new _P2); _C->AddParameter(new _P3); _C->AddParameter(new _P4); _C->AddParameter(new _P5); }

// Short Name
typedef MCommand				MCmd;
typedef MCommandDesc			MCmdDesc;