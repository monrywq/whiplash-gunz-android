#ifdef USE_WEBSOCKET

#define ASIO_STANDALONE
#define ASIO_HAS_STD_CHRONO
#define WEBSOCKETPP_STRICT_MASKING

#include "WebSocketListener.h"
#include <array>
#include <cstring>
#include <vector>

// ---------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------
bool WebSocketListener::Start(uint16_t port,
                              CallbackType callback,
                              UdpCallbackType udpCallback,
                              uint16_t udpPort)
{
    m_callback    = std::move(callback);
    m_udpCallback = std::move(udpCallback);
    m_udpPort     = udpPort;

    // Suppress all logging from websocketpp
    m_server.clear_access_channels(websocketpp::log::alevel::all);
    m_server.clear_error_channels(websocketpp::log::elevel::all);

    m_server.init_asio();
    m_server.set_reuse_addr(true);

    m_server.set_open_handler(
        [this](WsConnectionHdl hdl) { OnOpen(hdl); });
    m_server.set_message_handler(
        [this](WsConnectionHdl hdl, WsServer::message_ptr msg) {
            OnMessage(hdl, msg);
        });
    m_server.set_close_handler(
        [this](WsConnectionHdl hdl) { OnClose(hdl); });

    try {
        // Explicitly bind to the IPv4 wildcard address so that only IPv4
        // connections are accepted. The default listen(port) on dual-stack
        // systems binds to "::" (IPv6 wildcard) and accepts IPv6 connections
        // (including ::1), which then crash in OnOpen() when to_v4() is called.
        asio::ip::tcp::endpoint ep4(asio::ip::address_v4::any(), port);
        m_server.listen(ep4);
        m_server.start_accept();
    } catch (const std::exception& e) {
        fprintf(stderr, "WebSocketListener::Start failed on port %u: %s\n", port, e.what());
        return false;
    }

    // Run websocketpp's io_service on a dedicated thread
    m_thread = std::thread([this] { m_server.run(); });
    return true;
}

// ---------------------------------------------------------------------------
// Stop
// ---------------------------------------------------------------------------
void WebSocketListener::Stop()
{
    websocketpp::lib::error_code ec;
    m_server.stop_listening(ec);
    m_server.stop();
    if (m_thread.joinable())
        m_thread.join();
}

// ---------------------------------------------------------------------------
// Context store (mirrors NetIO::SetContext / GetContext)
// ---------------------------------------------------------------------------
void WebSocketListener::SetContext(ConnectionHandle handle, void* context)
{
    std::lock_guard<std::mutex> lock(m_connMutex);
    m_contexts[handle] = context;
}

void* WebSocketListener::GetContext(ConnectionHandle handle) const
{
    std::lock_guard<std::mutex> lock(m_connMutex);
    auto it = m_contexts.find(handle);
    return (it != m_contexts.end()) ? it->second : nullptr;
}

// ---------------------------------------------------------------------------
// Disconnect — close a WebSocket connection by handle
// ---------------------------------------------------------------------------
void WebSocketListener::Disconnect(ConnectionHandle handle)
{
    WsConnectionHdl hdl;
    {
        std::lock_guard<std::mutex> lock(m_connMutex);
        auto it = m_connections.find(handle);
        if (it == m_connections.end()) return;
        hdl = it->second;
        // Clear context BEFORE close so that the OnClose callback (which fires
        // after the close handshake) cannot return a stale / already-freed
        // MCommObject* via GetContext().  MC_NET_CLEAR may free pCommObj while
        // the close handshake is still in flight, causing a use-after-free if
        // GetContext() returns the freed pointer to the Disconnect callback.
        m_contexts.erase(handle);
    }
    // Post close() onto the asio io_service thread instead of calling it
    // directly.  Calling m_server.close() from an external thread while the
    // asio thread may concurrently run OnClose() (which erases m_connections
    // and drops the last shared_ptr backing the weak_ptr hdl) creates a race
    // where hdl has already expired by the time close() tries to lock() it,
    // causing std::bad_weak_ptr.  Posting serialises the close onto the same
    // thread that owns the connection lifetime, matching the pattern used in
    // Send() and SendUDP().
    m_server.get_io_service().post([this, hdl]() mutable {
        websocketpp::lib::error_code ec;
        m_server.close(hdl, websocketpp::close::status::normal, "disconnect", ec);
    });
}

// ---------------------------------------------------------------------------
// HasConnection — returns true if handle belongs to an active WS connection
// ---------------------------------------------------------------------------
bool WebSocketListener::HasConnection(ConnectionHandle handle) const
{
    std::lock_guard<std::mutex> lock(m_connMutex);
    return m_connections.count(handle) > 0;
}

// ---------------------------------------------------------------------------
// OnOpen — new WebSocket connection accepted
// ---------------------------------------------------------------------------
void WebSocketListener::OnOpen(WsConnectionHdl hdl)
{
    auto conn   = m_server.get_con_from_hdl(hdl);
    auto handle = reinterpret_cast<ConnectionHandle>(conn.get());

    // Retrieve the remote endpoint for AcceptData
    auto& socket = conn->get_raw_socket();
    auto  ep     = socket.remote_endpoint();

    NetIO::AcceptData adata;
    // Extract IPv4 address in host-byte-order (to_ulong()), which matches what
    // NetIO.cpp expects. Guard against IPv6 connections that may arrive on
    // dual-stack systems despite listening on 0.0.0.0.
    {
        auto addr = ep.address();
        if (addr.is_v4()) {
            adata.Address = addr.to_v4().to_ulong();
        } else if (addr.is_v6()) {
            auto v6 = addr.to_v6();
            if (v6.is_v4_mapped()) {
                // IPv4-mapped IPv6 (::ffff:x.x.x.x) — extract the IPv4 part
                adata.Address = asio::ip::address_v4(v6.to_v4()).to_ulong();
            } else {
                // Pure IPv6 (e.g. ::1): fall back to loopback
                adata.Address = asio::ip::address_v4::loopback().to_ulong();
            }
        } else {
            adata.Address = 0;
        }
    }
    adata.Port = ep.port();

    {
        std::lock_guard<std::mutex> lock(m_connMutex);
        m_connections[handle] = hdl;
    }

    if (m_callback)
        m_callback(NetIO::IOOperation::Accept, handle, &adata);
}

// ---------------------------------------------------------------------------
// OnMessage — binary WebSocket frame received
//
// Wire format (client → server):
//   0x01 + [TCP payload]                         → IOOperation::Read
//   0x02 + IP(4) + Port(2 LE) + [UDP payload]    → UDP callback
// ---------------------------------------------------------------------------
void WebSocketListener::OnMessage(WsConnectionHdl hdl, WsServer::message_ptr msg)
{
    const auto& payload = msg->get_payload();
    if (payload.size() < 1) return;

    auto conn   = m_server.get_con_from_hdl(hdl);
    auto handle = reinterpret_cast<ConnectionHandle>(conn.get());

    const uint8_t type = static_cast<uint8_t>(payload[0]);

    if (type == 0x01)
    {
        // TCP frame: forward payload[1..] as IOOperation::Read
        const auto* data = reinterpret_cast<const uint8_t*>(payload.data()) + 1;
        size_t      size = payload.size() - 1;

        NetIO::ReadData rdata;
        rdata.Data = {const_cast<uint8_t*>(data), size};

        if (m_callback)
            m_callback(NetIO::IOOperation::Read, handle, &rdata);
    }
    else if (type == 0x02)
    {
        // UDP frame: payload[1..4]=IP, payload[5..6]=Port(LE), payload[7..]=data
        // The IP+Port in the frame are the *destination* (server) coordinates from
        // the client's perspective.  We ignore them and instead use the actual peer
        // IP of this WebSocket connection so the locator keys on the real client
        // address and can route responses back over the same WebSocket.
        if (payload.size() < 7) return;

        // Bytes 5-6 of the frame are the destination port (little-endian) from
        // the client's perspective.  Only route to the UDP callback if it matches
        // the Locator port; all other UDP packets (e.g. P2P / game-server probes)
        // are silently dropped — there is no game server to route them to.
        uint16_t destPort = static_cast<uint16_t>(
            static_cast<uint8_t>(payload[5]) |
            (static_cast<uint8_t>(payload[6]) << 8));
        if (destPort != m_udpPort) return;

        // Use the real peer IP of the WebSocket TCP connection, not the embedded IP.
        uint32_t peerIp = 0;
        {
            auto& socket = conn->get_raw_socket();
            auto  ep     = socket.remote_endpoint();
            auto  addr   = ep.address();
            if (addr.is_v4()) {
                peerIp = addr.to_v4().to_ulong();
            } else if (addr.is_v6()) {
                auto v6 = addr.to_v6();
                if (v6.is_v4_mapped())
                    peerIp = asio::ip::address_v4(v6.to_v4()).to_ulong();
                else
                    peerIp = asio::ip::address_v4::loopback().to_ulong();
            }
        }

        // Derive a stable synthetic port from the connection handle so the locator
        // can uniquely key on (peerIp, syntheticPort) even when two clients share
        // the same peer IP.  Use the low 16 bits of the handle, biased into the
        // ephemeral range [49152, 65535] with a fixed offset.
        uint16_t syntheticPort = static_cast<uint16_t>(
            49152u + (handle & 0x3FFFu));

        const uint8_t* p = reinterpret_cast<const uint8_t*>(payload.data()) + 7;
        uint32_t    udpSize = static_cast<uint32_t>(payload.size() - 7);

        if (m_udpCallback)
            m_udpCallback(handle, peerIp, syntheticPort,
                          reinterpret_cast<const char*>(p), udpSize);
    }
}

// ---------------------------------------------------------------------------
// OnClose — WebSocket connection closed
// ---------------------------------------------------------------------------
void WebSocketListener::OnClose(WsConnectionHdl hdl)
{
    auto conn   = m_server.get_con_from_hdl(hdl);
    auto handle = reinterpret_cast<ConnectionHandle>(conn.get());

    // Fire callback BEFORE erasing from context/connection maps so that
    // OnWsEvent(Disconnect) can still call GetContext(handle) successfully.
    if (m_callback)
        m_callback(NetIO::IOOperation::Disconnect, handle, nullptr);

    {
        std::lock_guard<std::mutex> lock(m_connMutex);
        m_connections.erase(handle);
        m_contexts.erase(handle);
    }
}

// ---------------------------------------------------------------------------
// Send — TCP response: [0x01] + payload
// ---------------------------------------------------------------------------
void WebSocketListener::Send(ConnectionHandle handle, const void* data, size_t len)
{
    WsConnectionHdl hdl;
    {
        std::lock_guard<std::mutex> lock(m_connMutex);
        auto it = m_connections.find(handle);
        if (it == m_connections.end()) return;
        hdl = it->second;
    }

    std::vector<uint8_t> buf(1 + len);
    buf[0] = 0x01;
    std::memcpy(buf.data() + 1, data, len);

    // websocketpp::server::send() is not thread-safe; post() serialises it.
    m_server.get_io_service().post([this, hdl, buf = std::move(buf)]() mutable {
        try {
            m_server.send(hdl, buf.data(), buf.size(),
                          websocketpp::frame::opcode::binary);
        } catch (...) {}
    });
}

// ---------------------------------------------------------------------------
// SendUDP — UDP response: [0x02] + IP(4) + Port(2 LE) + payload
// ---------------------------------------------------------------------------
void WebSocketListener::SendUDP(ConnectionHandle handle,
                                uint32_t srcIp, uint16_t srcPort,
                                const void* data, size_t len)
{
    WsConnectionHdl hdl;
    {
        std::lock_guard<std::mutex> lock(m_connMutex);
        auto it = m_connections.find(handle);
        if (it == m_connections.end()) return;
        hdl = it->second;
    }

    std::vector<uint8_t> buf(1 + 4 + 2 + len);
    buf[0] = 0x02;
    buf[1] = static_cast<uint8_t>((srcIp      ) & 0xFF);
    buf[2] = static_cast<uint8_t>((srcIp >>  8) & 0xFF);
    buf[3] = static_cast<uint8_t>((srcIp >> 16) & 0xFF);
    buf[4] = static_cast<uint8_t>((srcIp >> 24) & 0xFF);
    buf[5] = static_cast<uint8_t>((srcPort    ) & 0xFF);  // LE
    buf[6] = static_cast<uint8_t>((srcPort >> 8) & 0xFF);
    std::memcpy(buf.data() + 7, data, len);

    m_server.get_io_service().post([this, hdl, buf = std::move(buf)]() mutable {
        try {
            m_server.send(hdl, buf.data(), buf.size(),
                          websocketpp::frame::opcode::binary);
        } catch (...) {}
    });
}

#endif // USE_WEBSOCKET
