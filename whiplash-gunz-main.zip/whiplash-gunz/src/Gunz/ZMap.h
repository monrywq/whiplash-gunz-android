#pragma once
#include "ZFilePath.h"

void ZGetCurrMapPath(char* outPath, int maxlen);

template<size_t size>
void ZGetCurrMapPath(char(&outPath)[size]) {
	ZGetCurrMapPath(outPath, size);
}

bool InitMapSelectionWidget();
bool IsQuestDerivedGameType();