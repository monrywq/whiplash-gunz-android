#pragma once

void MSysInfoLog();