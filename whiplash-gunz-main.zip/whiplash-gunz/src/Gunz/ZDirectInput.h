#pragma once

#ifdef __EMSCRIPTEN__
#include <deque>
#endif

// ZDIBUFFER is defined in MDebugShim.h for WASM builds

class ZDirectInput {
protected:
	HMODULE					m_hD3DLibrary;
	BOOL					m_bInitialized;
	LPDIRECTINPUT8			m_pDI;				///< The DirectInput object         
	LPDIRECTINPUTDEVICE8	m_pKeyboard;		///< The keyboard device 
	BOOL					m_bImmediateMode;

	LPDIRECTINPUTDEVICE8	m_pMouse;			///< mouse device
	unsigned int			m_nMouseButtons;	///> mouse buttons
	bool					m_bMouseButtonStates[8]{};

	LPDIRECTINPUTDEVICE8	m_pJoystick;		///< joystick device
	unsigned int			m_nJoyButtons;		///< joystick buttons
	unsigned int			m_nJoyPovs;			///< joystick povs
	unsigned int			m_nFFAxis;			///< force feedback axis
	bool					m_bForceFeedback;
	LPDIRECTINPUTEFFECT		m_pFFEffect;		///< force feedback effect

#ifdef __EMSCRIPTEN__
	std::deque<ZDIBUFFER>	m_KeyboardBuffer;
	std::deque<ZDIBUFFER>	m_MouseBuffer;
#endif

#define KEYNAMETABLE_COUNT	256
	char*					m_szKeyNameTable[KEYNAMETABLE_COUNT];

	static BOOL CALLBACK EnumJoysticksCallback( const DIDEVICEINSTANCE* pdidInstance, VOID* pContext );
	static BOOL CALLBACK EnumJoyObjectsCallback( const DIDEVICEOBJECTINSTANCE* pdidoi, VOID* pContext );

public:
	ZDirectInput();
	virtual ~ZDirectInput();

	bool CreateDirectInput();
	bool Create(HWND hWnd, BOOL bExclusive=TRUE, BOOL bImmediateMode=TRUE);
	void Destroy(void);

	void OnActivate(bool bActive);

	BOOL IsInitialized()	{ return m_bInitialized; }

	DWORD GetKeyboardBufferedData(ZDIBUFFER* pBuffer,unsigned int nBuffer);
	const char* GetKeyName(u32 nKey);


	unsigned int GetMouseButtonCount()		{ return m_nMouseButtons; }
	DWORD GetMouseBufferedData(int* pSumX,int* pSumY, ZDIBUFFER* pBuffer,unsigned int nBuffer);
	bool GetImmediateData(DIMOUSESTATE2 *pdims2);

	unsigned int GetJoystickPovCount()		{ return m_nJoyPovs; }
	unsigned int GetJoystickButtonCount()	{ return m_nJoyButtons; }
	bool GetJoystickData(DIJOYSTATE2* pjs);

	bool SetDeviceForcesXY(int nXForce, int nYForce);

#ifdef __EMSCRIPTEN__
public:
	void AccumulateMouse(int dx, int dy) {
		m_nAccumMouseX += dx;
		m_nAccumMouseY += dy;
	}
	void PushKeyEvent(BYTE nKey, bool bPressed) {
		m_KeyboardBuffer.push_back({ nKey, bPressed });
		if (m_KeyboardBuffer.size() > 1024) m_KeyboardBuffer.pop_front();
	}
	void PushMouseButtonEvent(BYTE nButton, bool bPressed) {
		m_MouseBuffer.push_back({ nButton, bPressed });
		if (m_MouseBuffer.size() > 1024) m_MouseBuffer.pop_front();
	}
protected:
	int m_nAccumMouseX = 0;
	int m_nAccumMouseY = 0;
#endif
};

#define ISKEYDOWN(_ScanCodeTable, _ScanCode)	((_ScanCodeTable[_ScanCode]&0x80)?true:false)