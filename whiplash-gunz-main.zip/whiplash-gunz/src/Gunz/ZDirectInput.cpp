#include "stdafx.h"
#include "MDebug.h"
#include "ZDirectInput.h"

#ifdef _WIN32
#include <crtdbg.h>
#include "MUtil.h"

#pragma comment(lib,"dinput8.lib")

#define SAMPLE_BUFFER_SIZE 32  // arbitrary number of buffer elements

#undef _DONOTUSE_DINPUT_MOUSE

ZDirectInput::ZDirectInput(void) : m_nJoyButtons(0), m_nJoyPovs(0), m_bForceFeedback(false)
{
	m_bInitialized = FALSE;
	m_pDI = NULL;
	m_pKeyboard = NULL;
	m_pMouse = NULL;
	m_pJoystick = NULL;
	m_bImmediateMode = TRUE;

	for(int i=0; i<KEYNAMETABLE_COUNT; i++){
		m_szKeyNameTable[i] = NULL;
	}
	m_hD3DLibrary = NULL;
}

ZDirectInput::~ZDirectInput(void)
{
	Destroy();
}

// ... (existing implementation omitted for brevity in this mock-up, I will use a multi_replace or just wrap it all)
#else // WASM / Non-Windows stubs

ZDirectInput::ZDirectInput(void) : m_nJoyButtons(0), m_nJoyPovs(0), m_bForceFeedback(false) {
    m_bInitialized = FALSE;
    m_pDI = nullptr;
    m_pKeyboard = nullptr;
    m_pMouse = nullptr;
    m_pJoystick = nullptr;
    m_bImmediateMode = TRUE;
}

ZDirectInput::~ZDirectInput(void) {}

bool ZDirectInput::CreateDirectInput() { return true; }
bool ZDirectInput::Create(HWND hWnd, BOOL bExclusive, BOOL bImmediateMode) { m_bInitialized = TRUE; return true; }
void ZDirectInput::Destroy(void) { m_bInitialized = FALSE; }
void ZDirectInput::OnActivate(bool bActive) {}
DWORD ZDirectInput::GetKeyboardBufferedData(ZDIBUFFER* pBuffer, unsigned int nBuffer) { return 0; }
const char* ZDirectInput::GetKeyName(u32 nKey) { return "N/A"; }
DWORD ZDirectInput::GetMouseBufferedData(int* pSumX, int* pSumY, ZDIBUFFER* pBuffer, unsigned int nBuffer) { *pSumX = 0; *pSumY = 0; return 0; }
bool ZDirectInput::GetImmediateData(DIMOUSESTATE2 *pdims2) { return false; }
bool ZDirectInput::GetJoystickData(DIJOYSTATE2* pjs) { return false; }
bool ZDirectInput::SetDeviceForcesXY(int nXForce, int nYForce) { return true; }

#endif
