#include "stdafx.h"
#include "ZSkyBox.h"
#include "MDebug.h"
#include "RealSpace2.h"

using namespace RealSpace2;

ZSkyBox::ZSkyBox(std::unique_ptr<RVisualMesh> VMesh) : VMesh{ std::move(VMesh) }
{
	this->VMesh->m_pMesh->mbSkyBox = true;
	// Skybox should always render regardless of camera position:
	// disable view frustum culling so it is never incorrectly skipped.
	this->VMesh->SetCheckViewFrustum(false);
}

ZSkyBox::~ZSkyBox() = default;

void ZSkyBox::Render()
{
	// Translate the skybox mesh to follow the camera so it is always centred
	// on the player.  Without this, the fixed-origin mesh can fall outside the
	// view frustum when the camera moves away from the map origin.
	rmatrix matWorld = GetIdentityMatrix();
	matWorld._41 = RCameraPosition.x;
	matWorld._42 = RCameraPosition.y;
	matWorld._43 = RCameraPosition.z;
	VMesh->SetWorldMatrix(matWorld);
	VMesh->Frame();
	VMesh->Render();
}