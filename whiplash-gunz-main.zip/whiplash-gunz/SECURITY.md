# Security Policy

## Reporting a vulnerability

**Please do not report security vulnerabilities through public GitHub issues, discussions, or Discord channels.**

Instead, use one of these private channels:

1. **GitHub private vulnerability reporting (preferred)** — go to the repository's **Security** tab → **Report a vulnerability**. This opens a private advisory visible only to maintainers.
2. **Direct message** — contact the maintainer ([@LostMyCode](https://x.com/LostMyCode)) via X/Twitter DM, or a private DM to a maintainer on the community Discord (do not post in public channels).

Please include:

- A description of the vulnerability and its impact (client compromise, server crash/RCE, account takeover, cheating primitive, …).
- Steps to reproduce or a proof-of-concept (packet capture, malformed command, URL).
- The affected component: WASM client, native MatchServer, in-browser (worker) MatchServer, WebSocket listener, Admin HTTP API, or Google OAuth flow.

You can expect an acknowledgement within **72 hours** and a status update within **7 days**. Please give us a reasonable window to ship a fix before public disclosure — we will credit you in the advisory unless you prefer otherwise.

## Scope

In scope:

- Memory-safety issues in the MatchServer reachable from the network (malformed MCommand packets, WebSocket framing, oversized parameters).
- Authentication/authorization bypasses: Google ID token verification, session tokens, `REGISTRATION_SECRET` gating, Admin HTTP bearer auth.
- Privilege escalation or data disclosure through the Admin HTTP API.
- Vulnerabilities in the browser client that allow XSS/code execution via game data or server responses.

Hosted elsewhere: vulnerabilities in the **registration/Discord Lambda stack** belong to [whiplash-gunz-api](https://github.com/LostMyCode/whiplash-gunz-api)'s security policy. If you're unsure where a protocol-level issue belongs, report it in either place and we'll route it.

## Known design limitations (not vulnerabilities)

- The MCommand packet cipher (`MPacketCrypter` + `MMakeSeedKey`) is the **original 2005-era GunZ obfuscation layer**, kept for wire compatibility with existing clients. It is *not* modern cryptography and the project does not rely on it for confidentiality or integrity. Reports that it is weak are appreciated but considered known.
- The Admin HTTP API is plain HTTP with bearer-token auth, **by design intended for private networks only** (localhost / VPC). Never expose it to the public internet. Reports of unsafe *defaults* (e.g. binding publicly without a token) are in scope; reports that HTTP lacks TLS are known.
- Classic GunZ gameplay trusts clients for some movement/combat state; anti-cheat hardening is an ongoing effort, and cheating reports are handled as regular issues unless they cross into server compromise.

## Supported versions

Only the latest `main` branch is supported. There are no maintained release branches.
