#!/bin/bash
set -eo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMAGE="gunz-matchserver-builder:latest"
BUILD_TYPE="${1:-release}"

if [ "$BUILD_TYPE" = "clean" ]; then
    echo "Removing Docker build directories..."
    rm -rf "$SCRIPT_DIR/build-matchserver-docker" \
           "$SCRIPT_DIR/build-matchserver-docker-release"
    echo "Done."
    exit 0
fi

# Build the Docker image only if it does not already exist
if ! docker image inspect "$IMAGE" > /dev/null 2>&1; then
    echo "=== Building Docker image $IMAGE ==="
    docker build -f "$SCRIPT_DIR/Dockerfile.matchserver" -t "$IMAGE" "$SCRIPT_DIR"
fi

# Pre-create build directories on the host to avoid permission issues
mkdir -p "$SCRIPT_DIR/build-matchserver-docker"
mkdir -p "$SCRIPT_DIR/build-matchserver-docker-release"

echo "=== Running MatchServer build in Docker (type: $BUILD_TYPE) ==="
docker run \
    --rm \
    -v "$SCRIPT_DIR:/src" \
    -u "$(id -u):$(id -g)" \
    -e HOME=/tmp \
    -e DOCKER_BUILD=1 \
    "$IMAGE" \
    /src/build-matchserver-ws.sh "$BUILD_TYPE"
