#!/bin/bash
set -eo pipefail

# Local build script for GunzWasm (no Docker required)
# Run setup_emsdk.sh first if emcc is not available.
#
# Usage: ./build-wasm-client.sh [debug|release]

# Paths relative to the ogz-wasm project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_DIR="${SCRIPT_DIR}"
SOURCE_DIR="${SCRIPT_DIR}/src/wasm"

# Ensure locally installed cmake/ninja are on PATH
export PATH="${HOME}/.local/bin:${PATH}"

# Auto-load emsdk if not already loaded
if ! command -v emcc &> /dev/null && [ -f "${HOME}/emsdk/emsdk_env.sh" ]; then
    source "${HOME}/emsdk/emsdk_env.sh" > /dev/null 2>&1
fi

# Parse build type argument
BUILD_TYPE="Debug"
if [ "$1" = "release" ] || [ "$1" = "Release" ]; then
    BUILD_TYPE="Release"
elif [ "$1" = "debug" ] || [ "$1" = "Debug" ] || [ -z "$1" ]; then
    BUILD_TYPE="Debug"
else
    echo "Usage: $0 [debug|release]"
    echo "  debug   - Debug build with symbols (default)"
    echo "  release - Optimized build with _PUBLISH (suppresses debug overlay)"
    exit 1
fi

# Separate build directories to avoid rebuild cycles
if [ "$BUILD_TYPE" = "Release" ]; then
    BUILD_DIR="${WORKSPACE_DIR}/build-release"
else
    BUILD_DIR="${WORKSPACE_DIR}/build"
fi

# Docker builds use isolated dirs to avoid CMakeCache path conflicts with native builds
if [ -n "${DOCKER_BUILD:-}" ]; then
    if [ "$BUILD_TYPE" = "Release" ]; then
        BUILD_DIR="${WORKSPACE_DIR}/build-docker-release"
    else
        BUILD_DIR="${WORKSPACE_DIR}/build-docker"
    fi
fi

# Check that emcc is available
if ! command -v emcc &> /dev/null; then
    echo "Error: 'emcc' not found. Please run setup_emsdk.sh first, then:"
    echo "  source ~/emsdk/emsdk_env.sh"
    exit 1
fi

# Check that cmake is available
if ! command -v cmake &> /dev/null; then
    echo "Error: 'cmake' not found. Please run setup_emsdk.sh first."
    exit 1
fi

echo "Building GunzWasm (${BUILD_TYPE})"
echo "  Source : ${SOURCE_DIR}"
echo "  Build  : ${BUILD_DIR}"
echo "  emcc   : $(emcc --version | head -1)"
echo ""

# 1. Prepare Build Directory
mkdir -p "${BUILD_DIR}"
cd "${BUILD_DIR}"

# 2. Configure CMake
# EXTRA_CMAKE_ARGS lets callers (e.g. CI) inject extra -D flags such as
# -DCMAKE_CXX_COMPILER_LAUNCHER=ccache. Left unquoted so multiple space-separated
# args word-split into individual flags.
echo "Configuring CMake (${BUILD_TYPE})..."
emcmake cmake "${SOURCE_DIR}" -DCMAKE_BUILD_TYPE="${BUILD_TYPE}" ${EXTRA_CMAKE_ARGS:-} 2>&1 | grep -v "^-- "

# 3. Build
NPROC=$(nproc 2>/dev/null || sysctl -n hw.logicalcpu 2>/dev/null || echo 4)
echo "Compiling GunzWasm (using ${NPROC} jobs)..."
# The post-build hasher renames GunzWasm.js/.wasm, so a no-op incremental build
# would leave the unhashed files missing. Remove the entry output to force relink.
rm -f GunzWasm.html
# CXXFLAGS/CFLAGS "-w" suppresses compiler warnings; grep filters make's own warnings
CXXFLAGS="-w" CFLAGS="-w" emmake make -j"${NPROC}" GunzWasm 2>&1 \
    | grep -v -E "^make(\[[0-9]+\])?: [Ww]arning:|clock skew detected|has modification time"

# 4. Copy MatchServer Artifacts (worker mode -- optional)
# The in-browser WASM MatchServer (MatchServer.js/.wasm) only exists on branches
# where it has been built. When it is absent, worker mode is sealed off and the
# client still builds (WebSocket mode only). Presence of MatchServer.wasm gates
# the whole worker asset chain.
WORKER_ASSETS=0
if [ -f "${WORKSPACE_DIR}/src/matchserver-ws/MatchServer.wasm" ] && [ -f "${WORKSPACE_DIR}/src/matchserver-ws/MatchServer.js" ]; then
    echo "Copying MatchServer (worker mode enabled)..."
    cp -f "${WORKSPACE_DIR}/src/matchserver-ws/MatchServer.js" .
    cp -f "${WORKSPACE_DIR}/src/matchserver-ws/MatchServer.wasm" .
    cp -f "${SOURCE_DIR}/MatchServerWorker.js" .
    WORKER_ASSETS=1
else
    echo "MatchServer.wasm/.js not found -- skipping worker assets (worker mode sealed)."
fi

# 5. Minify MatchServerWorker.js (Release only, and only when worker assets exist)
if [ "${BUILD_TYPE}" = "Release" ] && [ "${WORKER_ASSETS}" = "1" ]; then
    echo "Minifying MatchServerWorker.js..."
    CLOSURE_BIN="${EMSDK}/upstream/emscripten/node_modules/.bin/google-closure-compiler"
    if [ -x "${CLOSURE_BIN}" ]; then
        "${CLOSURE_BIN}" \
            --compilation_level SIMPLE \
            --warning_level QUIET \
            --js MatchServerWorker.js \
            --js_output_file MatchServerWorker.min.js \
        && mv MatchServerWorker.min.js MatchServerWorker.js \
        && echo "  MatchServerWorker.js minified." \
        || echo "  WARNING: Closure Compiler failed. Using unminified file."
    else
        echo "  WARNING: Closure Compiler not found at ${CLOSURE_BIN}. Skipping minification."
    fi
fi

# 6. Content-hash output filenames for cache busting
echo "Hashing output filenames..."
python3 "${SOURCE_DIR}/hash_outputs.py" --build-dir "${BUILD_DIR}"

echo ""
echo "Build complete! (${BUILD_TYPE})"
if [ "$BUILD_TYPE" = "Release" ]; then
    echo "Output directory: ${BUILD_DIR}/"
else
    echo "Output directory: ${BUILD_DIR}/"
fi
